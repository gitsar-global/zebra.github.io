from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class RfModeConfigStruct:

    def __init__(self, pRfModeTableIndex, pTari):
        self.pRfModeTableIndex = pRfModeTableIndex
        self.pTari = pTari

    def __str__(self):
        return "Antenna RF Config:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


# noinspection PyMethodMayBeStatic
class RFModeConfig:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Get(self, antenna):
        """
        GET RF Mode antenna configuration
        :param antenna: antenna
        :return: RfModeConfigStruct object
        """
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        pRfModeTableIndex = ffi.new("unsigned int *")
        pTari = ffi.new("unsigned int *")

        log.info("getting antenna {} RF MODE".format(antenna))
        status = lib.RFID_GetRFMode(
            self.reader_handle, antenna, pRfModeTableIndex, pTari)
        if VerifyStatus(status):
            config = RfModeConfigStruct(pRfModeTableIndex[0], pTari[0])
            log.info("Antenna {} {}".format(antenna, config))
            return config
        else:
            log.error("get antenna rf mode failed")
            return None

    def Set(self, config, antenna=0):
        """
        SET RF Mode antenna configuration
        :param config: RfModeConfigStruct object
        :param antenna: antenna
        :return: True if success else False
        """
        assert isinstance(config, RfModeConfigStruct), log.error(
            "expected config to be RfMode instance")
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        pRfModeTableIndex = ffi.new("unsigned int *")
        pTari = ffi.new("unsigned int *")

        pRfModeTableIndex[0] = config.pRfModeTableIndex
        pTari[0] = config.pTari

        status = lib.RFID_SetRFMode(
            self.reader_handle, antenna, pRfModeTableIndex[0], pTari[0])
        return VerifyStatus(status)
