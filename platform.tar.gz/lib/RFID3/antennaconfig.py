from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class AntennaConfigStruct:

    def __init__(self, pReceiveSensitivityIndex, pTransmitPowerIndex, pTransmitFrequencyIndex):
        self.pReceiveSensitivityIndex = pReceiveSensitivityIndex
        self.pTransmitPowerIndex = pTransmitPowerIndex
        self.pTransmitFrequencyIndex = pTransmitFrequencyIndex

    def __str__(self):
        return "Antenna Config:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


# noinspection PyMethodMayBeStatic
class AntennaConfig:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Get(self, antenna):
        """
        Get antenna config
        :param antenna: antenna id
        :return: AntennaConfigStruct object
        """
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        pReceiveSensitivityIndex = ffi.new("unsigned short *")
        pTransmitPowerIndex = ffi.new("unsigned short *")
        pTransmitFrequencyIndex = ffi.new("unsigned short *")

        log.info("Getting antenna {} configuration".format(antenna))
        status = lib.RFID_GetAntennaConfig(
            self.reader_handle, antenna, pReceiveSensitivityIndex, pTransmitPowerIndex, pTransmitFrequencyIndex)
        if VerifyStatus(status):
            config = AntennaConfigStruct(
                pReceiveSensitivityIndex[0], pTransmitPowerIndex[0], pTransmitFrequencyIndex[0])
            log.info("antenna {} config: {}".format(antenna, config))
            return config
        else:
            log.error("get antenna config for antenna {} failed".format(antenna))
            return None

    def Set(self, config, antenna=0):
        """
        Set antenna config
        :param config: AntennaConfigStruct object
        :param antenna: antenna id
        :return: True if success else False
        """
        assert isinstance(config, AntennaConfigStruct), log.error(
            "expected config to be AntennaConfig instance")
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        pReceiveSensitivityIndex = ffi.new("unsigned short *")
        pTransmitPowerIndex = ffi.new("unsigned short *")
        pTransmitFrequencyIndex = ffi.new("unsigned short *")

        pReceiveSensitivityIndex[0] = config.pReceiveSensitivityIndex
        pTransmitPowerIndex[0] = config.pTransmitPowerIndex
        pTransmitFrequencyIndex[0] = config.pTransmitFrequencyIndex

        log.info("setting antenna config for antenna {} to {}".format(
            antenna, config))
        status = lib.RFID_SetAntennaConfig(
            self.reader_handle, antenna, pReceiveSensitivityIndex[0], pTransmitPowerIndex[0], pTransmitFrequencyIndex[0])

        if VerifyStatus(status):
            log.info(
                "set antenna config successful for antenna {}.".format(antenna))
            return True
        else:
            log.error("set antenna config failed for antenna {}.".format(antenna))
            return False
