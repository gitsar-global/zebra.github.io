var net = require('net');
var express = require("/usr/lib/node_modules/npm/node_modules/express");
var cross= require('/usr/lib/node_modules/npm/node_modules/cors');
var app = express();
var fs=require('fs');
var options = {
  key: fs.readFileSync('/mnt/readerconfig/ssl/server.key'),
  cert: fs.readFileSync('/mnt/readerconfig/ssl/server.crt')
};
var server = require('https').createServer(options,app);
var UIClientIO=require('/usr/lib/node_modules/npm/node_modules/socket.io').listen(server);
var StreamEnginHOST = '127.0.0.1';
var StreamEnginCommandPORT = 50017;
var StreamEnginDataPORT=50018;
var readRatePS=0;
var delay=3000;
var tagData={}; // empty Object
var key = "tag";
tagData[key] = [];
var count=1; 
var StreamEnginSocket = new net.Socket();
var StreamEnginDataSocket = new net.Socket();
var IsDataPortConnected=false;
var IsCommandPortConnected=false;
var logger = require('/usr/lib/node_modules/npm/node_modules/logger').createLogger('//var//log/messages');
//app1.use(cross()); 
app.use(cross());
var responsePending=false;
var isInventoryOn=false;
var preInventoryRunStatus=false;
var uiCommand="";
var startInventoryTime="";
var stopInventoryTime="";
var inventoryRunTime=0;
var inventoryRunTimeFromUI=0;
var timer=null;
var isInventoryOnPushData=false;
var currentAnteenaData="" ;
var tempAnteenaData= [] ;
var currentSession="";
var isDisConnectRequired=true;
var isHttps="";
var llrpConnectedToPushDataPort=false;
var llrpConnectedToFXEasyConnect=false;
var llrpConfig=""; //Port number IsSecure or not//
var isSecure=false;
var IsPushData=false;
var IsFxEasyConnect=false;
var IsReadTagPage=false;
var stopTime="";
var path    = require("path");
//NPM Server
var multer = require('/usr/lib/node_modules/npm/node_modules/multer');
var url = require('url');
var fsx=require('/usr/lib/node_modules/npm/node_modules/fs-extra');
var tar = require("/usr/lib/node_modules/npm/node_modules/tar/tar.js");
var fstream = require("/usr/lib/node_modules/npm/node_modules/fstream");
require('https').globalAgent.options.rejectUnauthorized = false; 
UIClientIO.set('log level', 1);
var isDisConnectAfterStop=false;
var IsDisconnectCallFromPushData=false;
var IsDisconnectCallFromFXEasyConnect=false;
var isLoad=true;
var isPushDataCommandProcessing=false;
var isFXEasyCommandProcessing=false;
var isDefaultDisconnect=false;
var serverLoaded=false;

server.listen(8001, function(){
  console.log('listening on 8001');
  logger.info('ReadTagServer:ReadTagsServer started on port: 8001');

 
}); 

app.get('/api/',function(req,res){
			res.end("Hello World");
});

app.get('/api/checkServerStatus',function(req,res){
	//logger.info('ReadTagServer:Stream engin connected:'+serverLoaded);
	//console.log('ReadTagServer:Stream engin connected:'+serverLoaded);
	
	if(serverLoaded)
		res.end("Connected");
	else
		res.end("Not Connected");

});
		
app.get('/addCertificate',function(req,res){

res.sendFile('/mnt/platform/www/addcertificate.html');

});
		
	

function update()
{
 serverLoaded=true;
}	
		
StreamEnginSocket.on('error', function(ex) {
		////console.log("handled error");
		logger.error('ReadTagServer:Stream engin disconnected with Error :'+ex);
		isInventoryOn=false;
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin disconnected with Error :"+ex);
		});



StreamEnginSocket.on('disconnect', function () {
		////console.log('disconnect');
		logger.info('ReadTagServer:Stream engin disconnected.');
		isInventoryOn=false;
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin disconnected:");
		IsCommandPortConnected=false;

		});

StreamEnginSocket.on('close', function () {
		////console.log('close');
		logger.info('ReadTagServer:Stream engin socket closed.');
		IsCommandPortConnected=false;
		isInventoryOn=false;
		UIClientIO.sockets.emit('StreamEnginClosed', "close");

		});

StreamEnginSocket.on('end', function() { 
		IsCommandPortConnected=false;
		isInventoryOn=false;
		////console.log('End disconnected from server');
		logger.info('ReadTagServer:Stream engin socket ended.');
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin disconnected:");
		});


StreamEnginDataSocket.on('error', function(ex) {
		////console.log("handled error");
		isInventoryOn=false;
		logger.error('ReadTagServer:Stream engin data port disconnected with Error :'+ex);
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin data port disconnected with Error :"+ex);
		});



StreamEnginDataSocket.on('disconnect', function () {
		////console.log('disconnect');
		isInventoryOn=false;
		IsDataPortConnected=false;
		logger.info('ReadTagServer:Stream engin data port disconnected.');
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin data port disconnected:");


		});

StreamEnginDataSocket.on('close', function () {
		////console.log('close');
		isInventoryOn=false;
		logger.info('ReadTagServer:Stream engin data port closed.');
		IsDataPortConnected=false;
		UIClientIO.sockets.emit('StreamEnginClosed', "close");

		});

StreamEnginDataSocket.on('end', function() { 
		IsDataPortConnected=false;
		isInventoryOn=false;
		////console.log('End disconnected from server');
		logger.info('ReadTagServer:Stream engin data port ended.');
		UIClientIO.sockets.emit('StreamEnginClosed', "Stream engin data port disconnected:");
		});  


// Connect to LLRP-> call back
StreamEnginSocket.on('data', function(data) {
	try
	{
		
		////console.log("StreamEnginSocket------:"+data+" ");
		if(data!= undefined)
		{

		var datastr = (data+" ").trim();
		////console.log("Connect Data:"+uiCommand+":"+datastr+"test");

		if(datastr.toLowerCase().indexOf("unable to establish")>-1)
		{
			logger.error(uiCommand+':'+datastr);
			uiCommand="";
			StreamEnginSocket.write('disconnect\r\n');
			////console.log(datastr);
			UIClientIO.sockets.emit('LLRPConnectFail', "Unable to establish connection to the reader.There is already a connected LLRP client to the reader.");
			isPushDataCommandProcessing=false;
			isFXEasyCommandProcessing=false;
			IsPushData=false;;
			IsFxEasyConnect=false;
			IsReadTagPage=false;
			llrpConnectedToPushDataPort=false;
			llrpConnectedToFXEasyConnect=false; 
		}
		else
		{
		if(datastr.toLowerCase().indexOf("ok")>-1)
		{

			if(isDisconnectCall==true)
			{
				////console.log("disconnect end");
				isDisconnectCall=false;
				if(uiCommand.indexOf("PushDataStart")<0 && uiCommand.indexOf("HttpPostStart")<0)
				{
					//console.log('setup.connection_config=,'+llrpConfig+' ,');
					StreamEnginSocket.write('setup.connection_config=,'+llrpConfig+' ,');
					return;
				}

			}

			if(uiCommand.indexOf("PushDataStart")>-1)
			{
				if(isInventoryOn==false && isInventoryOnFXEasyConnect==false)
				{
					logger.info('ReadTagServer:start Inventory command from Push Data port.');
					//console.log('ReadTagServer:start Inventory command from Push Data port.');
					try
					{
						//console.log('setup.operating_mode_serialPort=,'+llrpConfig+' ,');
						logger.info('ReadTagServer:setup.operating_mode_serialPort=,'+llrpConfig+' ,');
						IsPushData=true;
						IsFxEasyConnect=false;
						IsReadTagPage=false;
						StreamEnginSocket.write('setup.operating_mode_serialPort=,'+llrpConfig+' ,');
						//UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");
						llrpConnectedToPushDataPort=true;
						//UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");
					}
					catch(err)
					{
						logger.error('ReadTagServer:Failed to start Inventory:'+err);
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Error: Failed to start Inventory:'+err);
					}
				}else
				{
					if(isInventoryOn)
					{
						logger.error('ReadTagServer:Failed to start Inventory:Inventory is already running in Read tag page.');
						//console.log("Failed to start Inventory:Inventory is already running in Read tag page.");
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Inventory is already running in Read tag page.');
					}else
					{
						logger.error('ReadTagServer:Failed to start Inventory:Inventory is already running in FX Connect .');
						//console.log("Failed to start Inventory:Inventory is already running in FX Connect.");
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Inventory is already running in FX Connect.');
					}
				}
				uiCommand=""; 

			}else if(datastr.indexOf("InventoryRunning:FXConnect")>-1)
			{  
				//console.log("GetInventoryStatus: Inventory is already running on FX Connect HHTP Post.");
				//logger.info('ReadTagServerReadTagServer:Inventory is already running on FX Connect HHTP Post.');
				isInventoryOnFXEasyConnect=true;
				llrpConnectedToFXEasyConnect=true;
				IsFxEasyConnect	=true;	
				//isDisConnectAfterStop=true;
				//UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in FX Connect.");
				logger.info('InventoryRunning:FXConnect:Inventory is already running on FX Connect');
				
			}else if(datastr.indexOf("InventoryRunning:PushData")>-1)
			{
				//console.log("GetInventoryStatus: Inventory is already running on FX Connect.");
				logger.info('ReadTagServer:Inventory is already running on PushData.');
				isInventoryOnPushData=true;
				llrpConnectedToPushDataPort=true;
				IsPushData	=true;	
				logger.info('InventoryRunning:PushData');
				//isDisConnectAfterStop=true;	
				
			}
			else if(uiCommand.indexOf("HttpPostStart")>-1)
			{
				if(isInventoryOn==false && isInventoryOnPushData==false)
				{
					logger.info('ReadTagServer:start Inventory command from FX Connect.');
					//console.log('ReadTagServer:start Inventory command from FX Connect.');
					try
					{
						////console.log("llrpConfig:"+llrpConfig);
						//console.log('setup.operating_mode_FXConnect=,'+llrpConfig+' ,');
						logger.info('ReadTagServersetup.operating_mode_FXConnect=,'+llrpConfig+' ,');
						IsPushData=false;
						IsFxEasyConnect=true;
						IsReadTagPage=false;
						StreamEnginSocket.write('setup.operating_mode_FXConnect=,'+llrpConfig+' ,');
						//UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");
						llrpConnectedToFXEasyConnect=true;
						//UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");
					}
					catch(err)
					{
						logger.error('ReadTagServer:Failed to start Inventory:'+err);
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Error: Failed to start Inventory:'+err);
					}
				}else
				{
					if(isInventoryOn)
					{
						logger.error('ReadTagServer:Failed to start Inventory:Inventory is already running in Read tag page.');
						//console.log('Failed to start Inventory:Inventory is already running in Read tag page.');
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Inventory is already running in Read tag page.');
					}else
					{
						logger.error('ReadTagServer:Failed to start Inventory.Inventory is already running in push Serial Port.');
						//console.log('Failed to start Inventory:Inventory is already running in Serial Port.');
						UIClientIO.sockets.emit('InventoryStartOnReadTags', 'Inventory is already running in Serial Port.');	
					}
					
				}
				uiCommand="";

			}
				
			else if(uiCommand.indexOf("Start")>-1)
			{
				logger.info('ReadTagServer:start Inventory command from readtags.');
				 //console.log('ReadTagServer:start Inventory command from readtags');
				if(isInventoryOnPushData==false && isInventoryOnFXEasyConnect==false)
				{
					if(llrpConnectedToPushDataPort==false && llrpConnectedToFXEasyConnect==false)
					{

						if(currentAnteenaData!="")
						{

							isDisConnectRequired=false;
							logger.info('ReadTagServer:start Inventory command with new antennas.');
							//console.log('ReadTagServer:start Inventory command with new antennas.');
							var setData="setup.set_antenna_config=,"+ currentAnteenaData.replace(/,/g," 0 ,");
							logger.info('ReadTagServer:Setting antenna power. '+setData);
							try
							{
								IsSetAntennaDataCommandCallBackReponded=false;
								setTimeout(SetAntennaDataCommandCallBack, 1000, "setup.set_antenna_config");
								StreamEnginSocket.write(setData);
							}
							catch(err)
							{
								logger.error('ReadTagServer:Failed to send SetAntennaInfo command to streamengin:'+err);
								UIClientIO.sockets.emit('SetAntennaDataCommandCallBack', err);
							}


							setTimeout(function()
							{

								try
								{
									//console.log('ReadTagServer:setup.operating_mode=active\r\n');
									logger.info('ReadTagServer:setup.operating_mode=active\r\n');
									StreamEnginSocket.write('setup.operating_mode=active\r\n');
									IsPushData=false;
									IsFxEasyConnect=false;
									IsReadTagPage=true;
								}
								catch(err)
								{
									logger.error('ReadTagServer:Failed to start Inventory:'+err);
									UIClientIO.sockets.emit('InventoryStartOnReadTags', 'Error: Failed to start Inventory:'+err);
								}


							},1000);	



						}else
						{
							logger.info('ReadTagServer:start Inventory command with default antennas.');
							try
							{
								
								IsPushData=false;
								IsFxEasyConnect=false;								
							    IsReadTagPage=true;
								//console.log('ReadTagServer:setup.operating_mode=active\r\n');
								logger.info('ReadTagServer:setup.operating_mode=active\r\n');								
								StreamEnginSocket.write('setup.operating_mode=active\r\n');
							}
							catch(err)
							{
								logger.error('ReadTagServer:Failed to start Inventory:'+err);
								UIClientIO.sockets.emit('InventoryStartOnReadTags', 'Error: Failed to start Inventory:'+err);
							}


						}

					}else
					{
						if(llrpConnectedToPushDataPort)
						{
							logger.error('ReadTagServer:Failed to start Inventory.LLRP is already connected to Serial Port.');
							//console.log('Failed to start Inventory.LLRP is already connected to Serial Port.');
							UIClientIO.sockets.emit('InventoryStartOnReadTags', 'LLRP is already connected to Serial Port.');
						}else
						{
							logger.error('ReadTagServer:Failed to start Inventory.LLRP is already connected to FX Connect.');
							//console.log('Failed to start Inventory.LLRP is already connected to FX Connect.');
							UIClientIO.sockets.emit('InventoryStartOnReadTags', 'LLRP is already connected to FX Connect.');
						}							
						
					}

				}else
				{
					if(isInventoryOnPushData)
					{
						logger.error('ReadTagServer:Failed to start Inventory.Inventory is already running in push Serial Port.');
						//console.log('Failed to start Inventory.Inventory is already running in push Serial Port.');
						UIClientIO.sockets.emit('InventoryStartOnReadTags', 'Inventory is already running in Serial Port.');
					}else
					{
						logger.error('ReadTagServer:Failed to start Inventory:Inventory is already running in FX Connect.');
						//console.log('Failed to start Inventory:Inventory is already running in FX Connect.');
						UIClientIO.sockets.emit('InventoryStartCommandCallBack', 'Inventory is already running in FX Connect.');
					}				
				}
				uiCommand="";
			}
			else if(uiCommand.indexOf("setup.get_antenna_config=Init")>-1)
			{
				
				////console.log("setup.get_antenna_config=Init");
				logger.info("setup.get_antenna_config=Init");
				try
				{
					IsInitCommandCallBackReponded=false;		
					setTimeout(InitCommandCallBack, 7000, "setup.get_antenna_config=Init");
					StreamEnginSocket.write("setup.get_antenna_config=Init");
				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to send Init command to streamengin:'+err);
					UIClientIO.sockets.emit('InitCommandCallBack', 'Error:Failed to send Init command to streamengin:'+err);
				}
				uiCommand="";
			}
			else if(uiCommand.indexOf("GetAntennaData")>-1)
			{
				////console.log('client requested for Antenna data');
				logger.info('ReadTagServer:GetAntennaData command'+uiCommand);
				try
				{
					////console.log("currentAnteenaData:"+currentAnteenaData);

					if(currentAnteenaData=="")
					{

						////console.log("currentAnteenaData:"+ uiCommand);
						IsGetAntennaDataCommandCallBackReponded=false;
						setTimeout(GetAntennaDataCommandCallBack, 7000, uiCommand);
						var command=uiCommand.replace("GetAntennaData","");
						StreamEnginSocket.write(command);
					}else
					{
						////console.log(currentAnteenaData);
						IsGetAntennaDataCommandCallBackReponded=true;
						//datastr=datastr.replace("AntennaData:","");	
						StreamEnginSocket.write('disconnect\r\n');
						UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', currentAnteenaData.replace("AntennaData:",""));

					}


				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to send GetAntennaInfo command to streamengin:'+err);
					UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', 'Error:Failed to send GetAntennaInfo command to streamengin:'+err);
				}
				uiCommand="";

			}else if(uiCommand.indexOf('setup.set_antenna_config=')>-1)
			{
				////console.log(uiCommand);

				logger.info('ReadTagServer:SetAntennaData command.'+uiCommand);
				try
				{
					
					try{
						var newCommand="";
			
						if(tempAnteenaData.length>1)
						{
							var valuesToSave=uiCommand.split(",");
							
							 for(var i=0;i<tempAnteenaData.length-1;i++)
								{
								 var flg=true;
								 for(var j=0;j<valuesToSave.length-1;j++)
								 {
									 
								   var antenna=valuesToSave[j].substring(0,valuesToSave[j].indexOf(" "));
									////console.log(antenna);
									 if(antenna==i+1)
									 {
										 flg=false;
										 break;
									 }
									 
								 }
									
								 if(flg==true)
								 {
									  //uiCommand=uiCommand+tempAnteenaData[i]+" 0 ,"
								 }
									
								}
							
						}
					}catch(err)
					{
					}
					
					IsSetAntennaDataCommandCallBackReponded=false;
					setTimeout(SetAntennaDataCommandCallBack, 7000, uiCommand);
					StreamEnginSocket.write(uiCommand);


				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to send SetAntennaInfo command to streamengin:'+err);
					UIClientIO.sockets.emit('SetAntennaDataCommandCallBack', err);
				}
				uiCommand="";

			}

		}else if(datastr.toLowerCase().indexOf("pushdatastart:0")>-1)
		{
			logger.info('ReadTagServer:Inventory start Command sent Successfully.Waiting to start inventory.');
			//console.log('ReadTagServer:Inventory start Command sent Successfully.Waiting to start inventory.');
			//isInventoryOnPushData=true;	
			llrpConnectedToPushDataPort=true;
			isPushDataCommandProcessing=false;
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");			

			

		}else if(datastr.toLowerCase().indexOf("pushdatastart:1")>-1)
		{

			logger.info('ReadTagServer:Failed to start Inventory as Serial Port is not configured as Push Data Mode.');
			//console.log('Failed to start Inventory as Serial Port is not configured as Push Data Mode.');
			isInventoryOnPushData=false;
			llrpConnectedToPushDataPort=false;	
			isPushDataCommandProcessing=false;			
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Failed to start Inventory as Serial Port is not configured/commited as Push Data Mode.");

		}else if(datastr.toLowerCase().indexOf("pushdatastart:2")>-1)
		{

			logger.info('ReadTagServer:Unable to start Inventory.');
			//console.log('Unable to start Inventory.');
			isInventoryOnPushData=false;
			llrpConnectedToPushDataPort=false;	
			isPushDataCommandProcessing=false;				
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Unable to start Inventory.");

		}else if(datastr.toLowerCase().indexOf("pushdatastart:3")>-1)
		{

			logger.info('ReadTagServer:Unable to start Inventory.');
			//console.log('Unable to start Inventory.');
			isInventoryOnPushData=false;
			llrpConnectedToPushDataPort=false;	
			isPushDataCommandProcessing=false;				
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Streamengine: RFID handle already exist.");

		}else if(datastr.toLowerCase().indexOf("pushdatastart:4")>-1)
		{

			logger.info('ReadTagServer:Unable to start Inventory.');
			//console.log('Unable to start Inventory.');
			isInventoryOnPushData=false;
			llrpConnectedToPushDataPort=false;	
			isPushDataCommandProcessing=false;				
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Unable to establish connection to the reader.");

		}else if(datastr.toLowerCase().indexOf("pushdatastart:5")>-1)
		{

			logger.info('ReadTagServer:Unable to start Inventory.');
			//console.log('Unable to start Inventory.');
			isInventoryOnPushData=false;
			llrpConnectedToPushDataPort=false;	
			isPushDataCommandProcessing=false;				
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Serial Port: Unknown Error.");

		}else if(datastr.toLowerCase().indexOf("httppoststart:0")>-1)
		{

			logger.info('ReadTagServer:Inventory start Command sent Successfully.Waiting to start inventory.');
			//console.log('Inventory start Command sent Successfully.Waiting to start inventory.');
			//isInventoryOnPushData=true;	
			llrpConnectedToFXEasyConnect=true;
			isFXEasyCommandProcessing=false;
			IsFxEasyConnect=true;
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "success");			

		}else if(datastr.toLowerCase().indexOf("httppoststart:1")>-1)
		{

			logger.info('ReadTagServer:Failed to start Inventory as FX Connect is not configured/commited.');
			//console.log('Failed to start Inventory as FX Connect is not configured/commited.');
			isInventoryOnFXEasyConnect=false;
			llrpConnectedToFXEasyConnect=false;		
			isFXEasyCommandProcessing=false;
			IsFxEasyConnect=false;
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Failed to start Inventory as FX Connect is not configured/commited.");

		}else if(datastr.toLowerCase().indexOf("httppoststart:2")>-1)
		{

			logger.info('ReadTagServer:Unable to start Inventory.');
			//console.log('Unable to start Inventory.');
			isInventoryOnFXEasyConnect=false;
			isFXEasyCommandProcessing=false;
			llrpConnectedToFXEasyConnect=false;	
			IsFxEasyConnect=false;			
			////console.log(startInventoryTime);
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Unable to start Inventory.");

		}
		else if(datastr.toLowerCase().indexOf("httppoststart:3")>-1)
		{

			logger.info('ReadTagServer:Unable to connect: FX Connect mode mismatch');
			//console.log('Unable to connect: FX Connect mode mismatch ');
			//isInventoryOnPushData=true;	
			llrpConnectedToFXEasyConnect=false;
			isFXEasyCommandProcessing=false;
			IsFxEasyConnect=false;
			UIClientIO.sockets.emit('InventoryStartCommandCallBack', "Unable to connect: FX Connect mode mismatch.");	
			

		}else if(datastr.indexOf("InventoryRunning:FXConnect")>-1)
		{
			//console.log("GetInventoryStatus: Inventory is already running on FX Connect.");
			logger.info('ReadTagServer:Inventory is already running on FX Connect.');
			isInventoryOnFXEasyConnect=true;
			llrpConnectedToFXEasyConnect=true;	
			IsFxEasyConnect	=true;
			logger.info('InventoryRunning:FXConnect1');
			UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in FX Connect.");			
			
			//isDisConnectAfterStop=true;			
		}else if(datastr.indexOf("InventoryRunning:PushData")>-1)
		{
			//console.log("GetInventoryStatus: Inventory is already running on FX Connect.");
			logger.info('ReadTagServer:Inventory is already running on PushData.');
			isInventoryOnPushData=true;
			llrpConnectedToPushDataPort=true;
			IsPushData	=true;	
			logger.info('InventoryRunning:PushData');
			//isDisConnectAfterStop=true;	
			
		}		
		else
		{
			//console.log("failed");
			logger.error(uiCommand+':'+datastr);
			if(datastr.indexOf("InventoryRunningOnEasyConnect")>-1)
			{
				isInventoryOnFXEasyConnect=true;
				UIClientIO.sockets.emit('LLRPConnectFail', "Inventory is already running on FX Connect.");
				uiCommand="";
			}
			else
			{
				//UIClientIO.sockets.emit('LLRPConnectFail', datastr);
				uiCommand="";
			}

		}
		}

		}else
		{
			
			logger.error(uiCommand+':Null data found');
			uiCommand="";

		}

	}catch(err)
	{
		logger.error(uiCommand+':'+err);
		uiCommand="";
	}
});	


var totalTag=0;
// data from data port
var isInventoryOnFXEasyConnect=false;

StreamEnginDataSocket.on('data', function(datastr) {


	try
	{
		if(datastr!= undefined)
		{
			if(datastr.indexOf("INVENTORY_START_EVENT")>-1)
			{
			
				if(IsPushData)
				{
					//console.log("PushData:INVENTORY_START_EVENT");
					//setup.operating_mode_serialPort=,portnumber sec*ure ,	
					isInventoryOnPushData=true;	
					llrpConnectedToPushDataPort=true;
					////console.log("PushDataStart:"+llrpConnectedToPushDataPort);
					logger.info('ReadTagServer:Inventory started in push data port.');
					//console.log('ReadTagServer:Inventory started in push data port.');
					UIClientIO.sockets.emit('InventoryStartOnPushData', "success");
			
				}else if(IsFxEasyConnect)
				{
					//console.log("FxEasyConnect:INVENTORY_START_EVENT");
					//setup.operating_mode_serialPort=,portnumber sec*ure ,	
					isInventoryOnFXEasyConnect=true;	
					llrpConnectedToFXEasyConnect=true;
					//console.log("FxEasyConnect:"+llrpConnectedToPushDataPort);
					logger.info('ReadTagServer:Inventory started in FX Connect.');
					//console.log('ReadTagServer:Inventory started in FX Connect.');
					UIClientIO.sockets.emit('InventoryStartOnFXEasyConnect', "success");
					
					
				}else if(IsReadTagPage)
				{
					//console.log("ReadTag:INVENTORY_START_EVENT");
					start() ;
					logger.info('ReadTagServer:Inventory started');
					isInventoryOn=true;
					startInventoryTime=new Date();				
					if(inventoryRunTimeFromUI>0)		
						startInventoryTime=new Date(startInventoryTime.setTime(startInventoryTime.getTime() - inventoryRunTimeFromUI))

					inventoryRunTimeFromUI=0;
					stopInventoryTime="";
					////console.log(startInventoryTime);
					//console.log('ReadTagServer:Inventory started in read tags page.');
					UIClientIO.sockets.emit('InventoryStartOnReadTags', "success");
				}			
				
				//console.log("startted");
				//UIClientIO.sockets.emit('INVENTORY_START_EVENT', "success");
			}
			else if(datastr.indexOf("INVENTORY_STOP_EVENT")>-1)
			{
				isInventoryOnPushData=false;
				isInventoryOn=false;
				isInventoryOnFXEasyConnect=false;
				
				
				
				if(IsPushData)
				{	
					IsInventoryStopOnPushDataCallBack=true;
					//console.log('PushData:INVENTORY_STOP_EVENT');
					logger.info('ReadTagServer:PushData:INVENTORY_STOP_EVENT');
					if(isDisConnectAfterStop)
					{
						StreamEnginSocket.write('disconnect\r\n');
						//console.log('disconnect sent for push data');
						logger.info('ReadTagServer:PushData:DISCONNECTION SENT');
						isDisConnectAfterStop=false;
					}
					UIClientIO.sockets.emit('InventoryStopOnPushData', "success");
					
				}if(IsFxEasyConnect)
				{	
					IsInventoryStopOnFXEasyConnectCallBack=true;
					//console.log('Fx Connect:INVENTORY_STOP_EVENT');
					logger.info('ReadTagServer:Fx Connect:INVENTORY_STOP_EVENT');
					if(isDisConnectAfterStop)
					{
						StreamEnginSocket.write('disconnect\r\n');
						//console.log('disconnect sent for FX Connect---------------');
						logger.info('ReadTagServer:FX Connect:DISCONNECTION SENT');
						isDisConnectAfterStop=false;
					}
					UIClientIO.sockets.emit('InventoryStopOnFXEasyConnect', "success");
					
				}
				else if(IsReadTagPage)
				{	
						IsInventoryStopOnReadTagsCallBack=true;
						//console.log('ReadTag:INVENTORY_STOP_EVENT');
						logger.info('ReadTagServer:ReadTag:INVENTORY_STOP_EVENT');
						try
						{
						stopInventoryTime=new Date();
						//console.log(uiCommand);
						inventoryRunTimeFromUI=stopTime;
						}catch(err)
						{
							//console.log(err);
						}
						//console.log("0");
						clearInterval(timer);
						//console.log("1");
						if( tagData.tag.length>0)
						{
							tagData.tag[0].RT="Read Rate :<b>"+readRatePS+"</b>  Total Tags:<b>"+totalTag+"</b>";
						}
						//console.log("2");
						UIClientIO.sockets.emit('tagReport', tagData); 
						//console.log("3");
						UIClientIO.sockets.emit('InventoryStopOnReadTags', "success");
						//console.log("4");
						StreamEnginSocket.write('disconnect\r\n');
												
				}
				
				
			
				
			}
			else if(datastr.indexOf("DISCONNECTION_EVENT")>-1)
			{
				logger.info('ReadTagServer:LLRP_DISCONNECTION_EVENT');
				isInventoryOnPushData=false;
				llrpConnectedToPushDataPort=false
				isInventoryOn=false;
				IsDisconnectCallFromPushData=false;
				IsDisconnectCallFromFXEasyConnect=false;
				isInventoryOnFXEasyConnect=false;
				llrpConnectedToFXEasyConnect=false;
				
				if(isInventoryOn)
				{
					stopInventoryTime=new Date();	
					//inventoryRunTimeFromUI=parseInt(InventoryCommand.substring(InventoryCommand.indexOf(":")+1,InventoryCommand.lenght));
					////console.log("inventoryRunTimeFromUI:"+inventoryRunTimeFromUI);
					clearInterval(timer);
					isInventoryOn=false;
				} 
				//console.log("DISCONNECTION_EVENT");
				
				if(isDefaultDisconnect)
				{
					isDefaultDisconnect=false;	
				}else
					UIClientIO.sockets.emit('LLRP_DISCONNECTION_EVENT', "success");
				
			}
			else if(datastr.indexOf("TagData")>-1)
			{
				//isInventoryOn=true;
				if(isInventoryOn)
				{
					var tags=datastr.split("TagData:");
					totalTag=totalTag+(tags.length-1);
					for(var j=1;j<tags.length;j++)
					{
						try
						{		
							var arr = tags[j].split(",");			  
							//if(arr[4]!=null)
							//{
							var flg=0;
							var tag=arr[1];
							var antenna=arr[2];
							var date=arr[0];
							var rssi=arr[4];
							for (var i = 0; i < tagData.tag.length; i++) 
							{
								if(tag==tagData.tag[i].T)
								{	
									tagData.tag[i].C= tagData.tag[i].C+1;							
									tagData.tag[i].d = date;
									tagData.tag[i].R=rssi;
									tagData.tag[i].A=antenna;
									flg=1;						
									break;
								}
							}
							if(flg==0)
							{
								//var date=(arr[0].trim()).replace(new RegExp(" "), '');
								tagData[key].push({"d":date,"A":antenna,"R":arr[4],"T":tag,"C":1,"RT":""});			
							}

							//}
						}catch(err)
						{
							////console.log("error reading data:"+err)
							logger.error("ReadTagServer:Error reading data:"+err);
						}
					}
				}


			}else if(datastr.indexOf("AntennaInitData")>-1)
			{
				////console.log("AntennaInitData:"+datastr);
				IsInitCommandCallBackReponded=true;
				datastr=datastr.replace("AntennaInitData:","");	


				if(currentAnteenaData=="")
				{

					StreamEnginSocket.write('setup.get_antenna_config=GetAntennaData,1');
					UIClientIO.sockets.emit('InitCommandCallBack', datastr);
				}else
				{
					//StreamEnginSocket.write('setup.get_antenna_config=GetAntennaData,1');
					////console.log(currentAnteenaData);
					//IsGetAntennaDataCommandCallBackReponded=true;
					//datastr=datastr.replace("AntennaData:","");
					UIClientIO.sockets.emit('InitCommandCallBack', datastr);						
					StreamEnginSocket.write('disconnect\r\n');
					UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', currentAnteenaData.replace("AntennaData:",""));

				}
			}else if(datastr.indexOf("AntennaData")>-1)
			{
				////console.log(datastr);
				IsGetAntennaDataCommandCallBackReponded=true;
				datastr=datastr.replace("AntennaData:","");	
				StreamEnginSocket.write('disconnect\r\n');
				UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', datastr);

			}
			else if(datastr.indexOf("SetAntennaInfo")>-1)
			{
				currentAnteenaData=currentAnteenaData=datastr.substring(23);
				////console.log("SetAntennaInfo:"+datastr);
				IsSetAntennaDataCommandCallBackReponded=true;
				datastr=datastr.replace("SetAntennaInfo:","");
				
				if(datastr.indexOf("Success")>-1)
				{
                    datastr=datastr.replace("Success ","");
                    
					tempAnteenaData=datastr.split(",");
                   
					
				}
				if(isDisConnectRequired==true)
				{
					StreamEnginSocket.write('disconnect\r\n');
					UIClientIO.sockets.emit('SetAntennaDataCommandCallBack', datastr);

				}else
				{
					isDisConnectRequired=true;	
					if(datastr.indexOf("Error")>-1)
						UIClientIO.sockets.emit('SetAntennaDataFailCommandCallBack', "Inventory started with default antenna power levels.");

				}

			}else if(datastr.indexOf("InventoryRunning:FXConnect")>-1)
			{
				//console.log("GetInventoryStatus: Inventory is already running on FX Connect.");
				logger.info('ReadTagServer:Inventory is already running on FX Connect.');
				isInventoryOnFXEasyConnect=true;
				llrpConnectedToFXEasyConnect=true;
				IsFxEasyConnect	=true;	
				logger.info('InventoryRunning:FXConnect2');
				//isDisConnectAfterStop=true;	
				
			}else if(datastr.indexOf("InventoryRunning:PushData")>-1)
			{
				//console.log("GetInventoryStatus: Inventory is already running on FX Connect.");
				logger.info('ReadTagServer:Inventory is already running on PushData.');
				isInventoryOnPushData=true;
				llrpConnectedToPushDataPort=true;
				IsPushData	=true;	
				logger.info('InventoryRunning:PushData');
				//isDisConnectAfterStop=true;	
				
			}

		}
		else
		{
			////console.log("Null data found:");
		}
		}catch(err)
		{
			////console.log("error reading data:"+err)
			logger.error("ReadTagServer:Error reading data:"+err);
		}	

});

function sleep(delay) {
	var start = new Date().getTime();
	while (new Date().getTime() < start + delay);
}



function start() {  // use a one-off timer
	timer =setInterval(intervalFunc, 1000);
};  




var tick=0;
function intervalFunc() 
{


	if(isInventoryOn==true)
	{
		try
		{	
			tick=tick+1;
			//if(tick>5)
			//{
			if(tagData!=null && tagData.tag.length>0)
			{
				readRatePS=Math.round(totalTag/(tick));
				tagData.tag[0].RT="Read Rate (Tags read per second):<b>"+readRatePS+"   </b>Total Tags:<b>"+totalTag+"</b>";


				UIClientIO.sockets.emit('tagReport', tagData);   
			}

		}catch(err)
		{
			////console.log("Error while calculating read rate:"+err)
			logger.error("ReadTagServer:Error while calculating read rate:"+err);
		}
	}else
	{
		if(readRatePS!=0 && tagData!=null && tagData.tag.length>0)
		{			
			tagData.tag[0].RT="Read Rate : <b>"+readRatePS+"</b>   Total Tags:<b>"+totalTag+"</b>";
			UIClientIO.sockets.emit('tagReport', tagData); 
		}

	}	

}

var IsInitCommandCallBackReponded=false;
function InitCommandCallBack(args)
{
	if(IsInitCommandCallBackReponded==false)
	{
		//StreamEnginSocket.write('disconnect\r\n');
		if(IsCommandPortConnected==false || IsDataPortConnected==false)
			UIClientIO.sockets.emit('InitCommandCallBack', "Error:Stream Engine Closed");		
		else
			UIClientIO.sockets.emit('InitCommandCallBack', "Error:Failed to get InitCommand response,Please try again.");


	}


}

var IsGetAntennaDataCommandCallBackReponded=false;
function GetAntennaDataCommandCallBack(args)
{
	if(IsGetAntennaDataCommandCallBackReponded==false)
	{
		//StreamEnginSocket.write('disconnect\r\n');
		if(IsCommandPortConnected==false || IsDataPortConnected==false)
			UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', "Error:Stream Engine Closed");
		else
			UIClientIO.sockets.emit('GetAntennaDataCommandCallBack', "Error:Failed to get GetAntennaDataCommand response,Please try again.");
	}
}

var IsSetAntennaDataCommandCallBackReponded=false;
function SetAntennaDataCommandCallBack(args)
{
	if(IsSetAntennaDataCommandCallBackReponded==false)
	{
		if(isDisConnectRequired==false)
		{		
			isDisConnectRequired=true;	
			UIClientIO.sockets.emit('SetAntennaDataFailCommandCallBack', "Inventory started with default antenna power levels.");
			return;
		}
		//StreamEnginSocket.write('disconnect\r\n');
		if(IsCommandPortConnected==false || IsDataPortConnected==false)
			UIClientIO.sockets.emit('SetAntennaDataCommandCallBack', "Error:Stream Engine Closed");
		else
			UIClientIO.sockets.emit('SetAntennaDataCommandCallBack', "Error:Failed to apply settings,Please try again.");
	}
}


var IsInventoryStopOnReadTagsCallBack=false;
function InventoryStopOnReadTags(args)
{
	if(IsInventoryStopOnReadTagsCallBack==false)
	{
		//console.log('INVENTORY_STOP_EVENT in readtags page');
		try
		{
		stopInventoryTime=new Date();
		////console.log(uiCommand);
		inventoryRunTimeFromUI=stopTime;
		}catch(err)
		{
			//console.log(err);
		}
		//console.log("0");
		clearInterval(timer);
		//console.log("1");
		if( tagData.tag.length>0)
		{
			tagData.tag[0].RT="Read Rate :<b>"+readRatePS+"</b>  Total Tags:<b>"+totalTag+"</b>";
		}
		//console.log("2");
		UIClientIO.sockets.emit('tagReport', tagData); 
		//console.log("3");
		UIClientIO.sockets.emit('InventoryStopOnReadTags', "success");
		//console.log("4");
		StreamEnginSocket.write('disconnect\r\n');
		//IsInventoryStopOnReadTagsCallBack=false;
	}
	
}

var IsInventoryStopOnPushDataCallBack=false;
function InventoryStopOnPushData(args)
{
	if(IsInventoryStopOnPushDataCallBack==false)	
	{		
	
        	//console.log('INVENTORY_STOP_EVENT_Time_Out_');
				
				if(IsPushData)
				{	
					//console.log('INVENTORY_STOP_EVENT in PushData');
					if(isDisConnectAfterStop)
					{
						StreamEnginSocket.write('disconnect\r\n');
						//console.log('disconnect sent for push data');
						isDisConnectAfterStop=false;
					}
					UIClientIO.sockets.emit('InventoryStopOnPushData', "success");
					
				}
				
				//console.log("stopped");
				logger.info('ReadTagServer:Inventory stopped');
	}
}

var IsInventoryStopOnFXEasyConnectCallBack=false;
function InventoryStopOnFXEasyConnect(args)
{
	if(IsInventoryStopOnFXEasyConnectCallBack==false)	
	{		
	
        	//console.log('INVENTORY_STOP_EVENT_Time_Out_');
			logger.info('INVENTORY_STOP_EVENT_Time_Out_');
				
				if(IsFxEasyConnect)
				{	
					//console.log('INVENTORY_STOP_EVENT in FxEasyConnect_Time_Out ');
					logger.info('INVENTORY_STOP_EVENT in FxEasyConnect_Time_Out');
					if(isDisConnectAfterStop)
					{
						StreamEnginSocket.write('disconnect\r\n');
						//console.log('disconnect sent from Fx Connect_INVENTORY_STOP_EVENT_Time_Out ');
						isDisConnectAfterStop=false;
					}
					UIClientIO.sockets.emit('InventoryStopOnFXEasyConnect', "success");
					
				}
				
			
				logger.info('ReadTagServer:Inventory stopped_Time_out_END');
	}
}






function forceGC()
{
	if (global.gc) {
		global.gc();
	} else {
		console.warn('No GC hook! Start your program as `node --expose-gc ReadTagsServer.js`.');
	}
}		

	var isProcessingCommandReset=false;
	function resetProcessingCommand()
		{
			//console.log("inside resetProcessingCommand");
			if(isProcessingCommandReset)
			{
			isProcessingCommandReset=false;
			isPushDataCommandProcessing=false;
			isFXEasyCommandProcessing=false;
			//console.log("resetProcessingCommand Done");
			}

		}
		


UIClientIO.sockets.on('connection', function(socket) { 





		logger.info("ReadTagServer:UI Connected to node Socket.");
		if(tagData!=null && tagData.tag.length>0)
		{
			////console.log("sending tag data");
			UIClientIO.sockets.emit('tagReport', tagData); 

		}


		if(!IsCommandPortConnected) 
		{
		logger.info("ReadTagServer:Node Server trying to connect streamengin command Socket");
		StreamEnginSocket.connect(StreamEnginCommandPORT, StreamEnginHOST, function() {
			IsCommandPortConnected=true;
			//console.log("Calling update");
			update();
			logger.info("ReadTagServer:Node Connected to streamengin command socket---");
			    if(isLoad)
				{
					isLoad=false;
					//console.log("Sent getInventoryStatus to StreamEngin.");
					logger.info("ReadTagServer:Sent getInventoryStatus to StreamEngin.");
					StreamEnginSocket.write('getInventoryStatus\r\n');
					
				}
				StreamEnginSocket.write('Connect');
				////console.log('Connected to streaming engin on: ' + StreamEnginHOST + ':' + StreamEnginCommandPORT);
				logger.info('ReadTagServer:Connected to streaming engin on: ' + StreamEnginHOST + ':' + StreamEnginCommandPORT);
				isInventoryOn=false;	
				inventoryRunTime=0;
				stopInventoryTime="";
				startInventoryTime="";	
				
				
				UIClientIO.sockets.emit('StreamEnginConnected', "Command port connected");

				});
		}else
		{
			StreamEnginSocket.write('getInventoryStatus\r\n');
		}

		if(!IsDataPortConnected) 
		{
			logger.info("ReadTagServer:Node Server trying to connect streamengin data Socket");
			StreamEnginDataSocket.connect(StreamEnginDataPORT, StreamEnginHOST, function() {
				logger.info("ReadTagServer:Node Connected to streamengin data socket");
					StreamEnginSocket.write('Connect');
					////console.log('Connected to streaming engin on data port: ' + StreamEnginHOST + ':' + StreamEnginDataPORT);
					logger.info('ReadTagServer:Connected to streaming engin on data port: ' + StreamEnginHOST + ':' + StreamEnginDataPORT);
					IsDataPortConnected=true;
					isInventoryOn=false;
					StreamEnginDataSocket.setEncoding(null);				
					clearInterval(timer);				
					UIClientIO.sockets.emit('StreamEnginConnected', "Data port connected");

					});
		}else
		{
			////console.log('Data port is already connected.');
		}

		socket.on('error', function(ex) {
				////console.log('Node Server disconnected with Error :'+ex);
				logger.error('ReadTagServer:Node Server disconnected with Error :'+ex);

				});


		socket.on('ConnectAckFromUI', function(Command) 
			{ 
				    //console.log("ConnectAckFromUI-------------------"+Command);	
					isFXEasyCommandProcessing=false;
					isPushDataCommandProcessing=false;
					isProcessingCommandReset=false;
				
			}); 
				
		socket.on('CheckServerStatus', function(Command) 
			{ 
				logger.info('ReadTagServer:LLRPConnect sent:'+IsCommandPortConnected+serverLoaded );
				if(IsCommandPortConnected)  
				UIClientIO.sockets.emit('ServerStatus', "Connected");
			});			
			
		socket.on('LLRPConnect', function(Command) 
		{ 
			//console.log("");
			//console.log("---------------------------------------------");
			//console.log("LLrp connect:"+Command);
			
			if(Command.indexOf("@")>-1)
			{
				try
				{
					var arr=Command.split("@");
				
					if(arr.length>0)
					{
					
						Command=arr[0];
						//console.log("Command"+ Command)
						llrpConfig=arr[1];
						
					
					}
				}
				catch(err)
				{
					//console.log("index:Error");
					logger.info('ReadTagServer:LLrp connect Command:'+err);
				}
			}
			
			if(isInventoryOn==false && isInventoryOnPushData==false && isInventoryOnFXEasyConnect==false)
			{
			
				////console.log("index:"+Command.indexOf("PushDataStart"));
				if(Command.indexOf("PushDataStart")<0 && Command.indexOf("HttpPostStart")<0)
				{

					if(llrpConnectedToPushDataPort || isPushDataCommandProcessing)
					{
						if(isPushDataCommandProcessing)
						{
							UIClientIO.sockets.emit('CheckInventoryCommand', "PushData:3");
							//console.log("PushData:3");
							
						}else
						{
							UIClientIO.sockets.emit('CheckInventoryCommand', "LLRP is already connected to Serial Port.");
							logger.info('ReadTagServer:LLRP is already connected to Serial Port.');
							//console.log("LLRP is already connected to Serial Port.");
						}
						
					}else if(llrpConnectedToFXEasyConnect || isFXEasyCommandProcessing)
					{
						if(isFXEasyCommandProcessing)
						{
							UIClientIO.sockets.emit('CheckInventoryCommand', "FXEasyConnect:3");
							//console.log("FXEasyConnect:3");
							
							
						}else		
						{						
							UIClientIO.sockets.emit('CheckInventoryCommand', "LLRP is already connected to FX Connect.");
							logger.info('ReadTagServer:LLRP is already connected to FX Connect');
							//console.log("LLRP is already connected to FX Connect");
						}
					}else
					{
						//console.log("LLRPConnect sent:"+Command);
						//logger.info('ReadTagServer:LLRPConnect sent:'+Command);
						isDisconnectCall=true;
						isDefaultDisconnect=true;
						IsReadTagPage=true;
						IsPushData=false;
						IsFxEasyConnect=false;
						uiCommand=Command;
						StreamEnginSocket.write('disconnect\r\n');
						
					}
				}else 
				{
					
					//console.log("LLRPConnect-----------------------"+Command);
					//logger.info('ReadTagServer:LLRPConnect sent:'+Command);
					isDisconnectCall=true;
					isDefaultDisconnect=true;
					uiCommand=Command;
					if(Command.indexOf("PushDataStart")>-1)
					{
						IsPushData=true;
						IsFxEasyConnect=false;
						IsReadTagPage=false;
						isPushDataCommandProcessing=true;
						isFXEasyCommandProcessing=false;
						isProcessingCommandReset=true;
						setTimeout(resetProcessingCommand, 20000);
						
					}else	
					if(Command.indexOf("HttpPostStart")>-1)
					{
						IsFxEasyConnect=true;
						IsPushData=false;
						IsReadTagPage=false;
						isPushDataCommandProcessing=false ;
						isFXEasyCommandProcessing=true;
						isProcessingCommandReset=true;
						setTimeout(resetProcessingCommand, 20000);
					}
						
					StreamEnginSocket.write('disconnect\r\n');
				
				}
				

			}
			else
			{
				if(isInventoryOnPushData)
				{
					//console.log("Inventory in progress in push data mode.");
					logger.info('ReadTagServer:Inventory in progress in push data mode.');
					UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in Serial Port.");

				}else if(isInventoryOnFXEasyConnect)
				{
					//console.log("Inventory in progress in debug mode.");
					logger.info('ReadTagServer:Inventory is already running in FX Connect.');
					UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in FX Connect.");
					
				}else
				{
					//console.log("Inventory in progress in http post.");
					logger.info('ReadTagServer:Inventory is already running in Read tag page.');
					UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in Read tag page.");
				}
			}
		});

		
	
		
		
		socket.on('InventoryStatus', function(Command) 
		{ 
			//console.log("Inventory Status check :"+Command);
			logger.info('Inventory Status check :'+Command);
			if(isInventoryOn)
			{
				//console.log("Inventory in progress in debug mode.");
				UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in Read tag page.");
			}else
			if(isInventoryOnPushData)
			{
				//console.log("Inventory in progress in push data mode.");
				if(!IsDisconnectCallFromPushData)
					UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in Serial Port.");
				else
					UIClientIO.sockets.emit('CheckInventoryCommand', "PushData:1");
			}else			
			if(isInventoryOnFXEasyConnect)
			{
			    //console.log("Inventory in progress in FX Connect.");
				if(!IsDisconnectCallFromFXEasyConnect)
					UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory is already running in FX Connect.");
				else
					UIClientIO.sockets.emit('CheckInventoryCommand', "FXEasyConnect:1");
			}else 			
			if(llrpConnectedToPushDataPort)
			{
				//console.log("LLRP already connected to Serial Port..");
				if(!IsDisconnectCallFromPushData)
					UIClientIO.sockets.emit('CheckInventoryCommand', "LLRP already connected to Serial Port.");
				else
					UIClientIO.sockets.emit('CheckInventoryCommand', "PushData:2");
			}
			else
			if(llrpConnectedToFXEasyConnect)
			{
				//console.log("LLRP already connected to FXEasyConnect");
				if(!IsDisconnectCallFromFXEasyConnect)
					UIClientIO.sockets.emit('CheckInventoryCommand', "LLRP already connected to FX Connect.");
				else
					UIClientIO.sockets.emit('CheckInventoryCommand', "FXEasyConnect:2");
			}
			else
			if(isPushDataCommandProcessing)
			{
				//console.log(isPushDataCommandProcessing);
				UIClientIO.sockets.emit('CheckInventoryCommand', "PushData:3");
			}
			else
			if(isFXEasyCommandProcessing)
			{
				//console.log(isFXEasyCommandProcessing);
				UIClientIO.sockets.emit('CheckInventoryCommand', "FXEasyConnect:3");
			}else
			if(Command=="CheckStatus")
			{
				//console.log("CheckStatus:False");
				UIClientIO.sockets.emit('CheckInventoryCommand', "false");
			}
		   logger.info('Inventory Status check end:'+Command);
		   //console.log("Inventory Status check Exit:"+Command);
			
		});


		



		socket.on('LLRPDisconnect', function(Command) 
		{ 
			StreamEnginSocket.write('disconnect\r\n');
		});


		socket.on('UserSession', function(session) 
		{ 
		////console.log(session);
			if(currentSession!=session)
			{  
				////console.log(currentSession);
				currentSession=session;
				currentAnteenaData="";

			}
		});
		

		

		socket.on('InventoryCommand', function(InventoryCommand) 
		{ 

			logger.info('ReadTagServer:'+InventoryCommand);
			//console.log("\r\n------------------------------------");
			//console.log(InventoryCommand);
			if(InventoryCommand.indexOf("PushDataStop")>-1)
			{
				IsDisconnectCallFromPushData=true;
				logger.info('ReadTagServer:Inventory stop command from Push data Port:');
				//console.log('ReadTagServer:Inventory stop command from Push data Port:');
				IsPushData=true;
				IsFxEasyConnect=false;
				IsReadTagPage=false;
				try
				{
				
					if(isInventoryOnPushData)
					{
						//console.log('setup.operating_mode=standby\r\n');
						logger.info("ReadTagServer:setup.operating_mode=standby\r\n");
						isDisConnectAfterStop=true;
						IsInventoryStopOnPushDataCallBack=false;
						setTimeout(InventoryStopOnPushData, 7000, InventoryCommand);
						StreamEnginSocket.write('setup.operating_mode=standby\r\n');
					
						
					}else
					{
						//console.log('disconnect\r\n');
						logger.info("ReadTagServer:disconnect");
						StreamEnginSocket.write('disconnect\r\n');
					
						
					}
				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to stop Inventory:'+err);
					UIClientIO.sockets.emit('InventoryStopOnPushData', 'Error: Failed to stop Inventory:'+err);

				}

			}else if(InventoryCommand.indexOf("FxEasyConnectStop")>-1)
			{
				IsDisconnectCallFromFXEasyConnect=true;
				logger.info('ReadTagServer:Inventory stop command from FX Connect.');
				//console.log('ReadTagServer:Inventory stop command from FX Connect.');
				IsFxEasyConnect=true;
				IsPushData=false;
				IsReadTagPage=false;
				try
				{
				
					if(isInventoryOnFXEasyConnect)
					{
						//console.log('setup.operating_mode=standby\r\n');
						logger.info('ReadTagServer:setup.operating_mode=standby\r\n');
						isDisConnectAfterStop=true;
						IsInventoryStopOnFXEasyConnectCallBack=false;
						setTimeout(InventoryStopOnFXEasyConnect, 7000, InventoryCommand);
						StreamEnginSocket.write('setup.operating_mode=standby\r\n');
					
						
					}else
					{
						//console.log('disconnect\r\n');
						logger.info('ReadTagServer:disconnect\r\n');
						StreamEnginSocket.write('disconnect\r\n');
					
						
					}
				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to stop Inventory:'+err);
					UIClientIO.sockets.emit('InventoryStopOnPushData', 'Error: Failed to stop Inventory:'+err);

				}

			}
			else if(InventoryCommand.indexOf("Stop")>-1)
			{
				
				IsInventoryStopOnReadTagsCallBack=false;
				logger.info('ReadTagServer:Inventory stop command.');
				//console.log('Inventory stop command from readtags');
				IsPushData=false;
				IsFxEasyConnect=false;
				IsReadTagPage=true;
				try
				{
				    stopTime=parseInt(InventoryCommand.substring(InventoryCommand.indexOf(":")+1,InventoryCommand.lenght));
					setTimeout(InventoryStopOnReadTags, 7000, InventoryCommand);
					logger.info('ReadTagServer:setup.operating_mode=standby\r\n');
					//console.log('setup.operating_mode=standby\r\n');
					StreamEnginSocket.write('setup.operating_mode=standby\r\n');
					
				}
				catch(err)
				{
					logger.error('ReadTagServer:Failed to stop Inventory:'+err);
					UIClientIO.sockets.emit('InventoryStopOnReadTags', 'Error: Failed to stop Inventory:'+err);

				}

			}else if(InventoryCommand=="ClearData")
				{
					logger.info('ReadTagServer:Inventory data clear command');
					try
					{


						inventoryRunTime=0;
						stopInventoryTime="";
						
						if(isInventoryOn)
						startInventoryTime=new Date();
						else
						startInventoryTime=undefined;
					
						inventoryRunTimeFromUI=0;



						for (var k in tagData) {
							if( tagData.hasOwnProperty(k) ) {
								tagData[k]=undefined;
							} 
						}  

						tagData=undefined;
						tagData={}; // empty Object
						tagData[key] = [];
						tick=0;
						//////console.log(tagData.tag[0].RT);
						totalTag=0;
						readRatePS=0;
						//forceGC();
						UIClientIO.sockets.emit('InventoryClearDataCommandCallBack', "success");	
						//},delay);	
				}
			catch(err)
			{
				logger.error('ReadTagServer:Failed to stop Inventory:'+err);
				UIClientIO.sockets.emit('InventoryClearDataCommandCallBack', 'Error:'+err);
			}

			}

		});

		
		socket.on('StopTimeFromUI', function(StopTIme) 
		{
			inventoryRunTimeFromUI=parseInt(StopTIme.substring(StopTIme.indexOf(":")+1,StopTIme.lenght));
			////console.log("Inventory stopped with : "+ inventoryRunTimeFromUI);
		});
		
		
	socket.on('StartStopTIme', function(StartStopTIme) 
		{ 
			var diff;

			////console.log("timer");
			//if( tagData.tag.length>0)
			//{

				if(inventoryRunTimeFromUI==0)
				{

					if(startInventoryTime!=undefined && startInventoryTime!="")
					{

						if(stopInventoryTime!=undefined && stopInventoryTime!="")
						{
						// diff=moment.utc(moment(stopInventoryTime,"DD/MM/YYYY HH:mm:ss").diff(moment(startInventoryTime,"DD/MM/YYYY HH:mm:ss")));


						diff= (stopInventoryTime.getTime())-startInventoryTime.getTime();
						}
						else
						{
							//var now=moment().format('DD/MM/YYYY HH:mm:ss');
							//diff=moment.utc(moment(now,"DD/MM/YYYY HH:mm:ss").diff(moment(startInventoryTime,"DD/MM/YYYY HH:mm:ss")));
							//diff=moment.utc(moment().format('DD/MM/YYYY HH:mm:ss').diff(moment(startInventoryTime,"DD/MM/YYYY HH:mm:ss")));


							diff= (new Date().getTime())-startInventoryTime.getTime();
						}
						////console.log("diff"+diff);	
						inventoryRunTime=diff;
						UIClientIO.sockets.emit('StartStopTIme', diff);

					}
					else
					{
						////console.log("StartStopTIme not");
					}
				}else
				{
					////console.log("inventoryRunTimeFromUI"+inventoryRunTimeFromUI);
					UIClientIO.sockets.emit('StartStopTIme', inventoryRunTimeFromUI);
					//inventoryRunTimeFromUI=0;
				}
			//}
		});

	socket.on('LLRPDisconnected', function(LLRPDisconnected) 
	{
		////console.log("LLRPDisconnected");
		clearInterval(timer);
		preInventoryRunStatus=isInventoryOn;
		isInventoryOn=false;
	});

	socket.on('LLRPConnected', function(LLRPDisconnected) 
		{
			if(isInventoryOn==false)
			{
				////console.log("LLRPConnected");
				isInventoryOn=preInventoryRunStatus;
				start();
			}
		});



	socket.on('AntennaDataCommand', function(AntennaDataCommand) 
	{ 
		if(isInventoryOn==false)
		{
			logger.info('ReadTagServer:AntennaDataCommand.'+AntennaDataCommand);
			isDisconnectCall=true;
			uiCommand="AntennaDataCommand:"+AntennaDataCommand;
			StreamEnginSocket.write('disconnect\r\n');
			//uiCommand="AntennaDataCommand:"+AntennaDataCommand;
			//sleep(4000);
			//StreamEnginSocket.write('connect\r\n');
		}else
		{
			UIClientIO.sockets.emit('CheckInventoryCommand', "Inventory in progress:Please stop Inventory to proceed with antenna configuration.");
		}
	});			
});

		
		


var isDisconnectCall=false;
var csocket;





//NPM


var Storage = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "/var/volatile/");
    },
    filename: function (req, file, callback) {
        callback(null,  file.originalname);
    }
});


var StorageUseApps = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "/var/volatile/tmp/");
    },
    filename: function (req, file, callback) {
        callback(null,  file.originalname);
    }
});

var StorageLicense = multer.diskStorage({
    destination: function (req, file, callback) {
        callback(null, "/var/volatile/tmp/");
    },
    filename: function (req, file, callback) {
        callback(null,  file.originalname);
    }
});




var upload = multer({ storage : Storage}).array('imgUploader',2);;
var uploadUserApps = multer({ storage : StorageUseApps}).array('imgUploader',2);
var uploadForLicense = multer({ storage : StorageLicense}).array('imgUploader',2);;



//var upload = multer({ storage : storage }).array('userPhoto',2);



app.post('/api/uploadFiles',function(req,res){
	try{
		upload(req,res,function(err) {
			//console.log("uploading file.");
			if(err) {
				logger.error("NPMServer:Failed to upload firmware file(s)"+err);
				return res.end("Error uploading file."+err);
			}
			////console.log("File uploaded");
			res.end("success");
		});
	}catch(err)
	{
		logger.error("NPMServer:Failed to upload firmware file(s)"+err);
	}
});


app.post('/api/uploadFilesForUserApps',function(req,res){
	try{
		uploadUserApps(req,res,function(err) {
			//console.log("uploading file.");
			
			if(err) {
				logger.error("NPMServer:Failed to upload user application file."+err);
				//console.log("NPMServer:Failed to upload user application file."+err);
				return res.end("Error uploading file."+err);
			}
			//console.log("File uploaded");
			res.end("success");
		});
	}catch(err)
	{
		logger.error("NPMServer:Failed to upload user application file."+err);
	}
});


app.post('/api/uploadLicense',function(req,res){
	try{
		 	  
		
		uploadForLicense(req,res,function(err) {
			////console.log("uploading file.");
			
			if(err) {
				logger.error("NPMServer:Failed to upload License file."+err);
				////console.log("NPMServer:Failed to upload License file."+err);
				return res.end("Error uploading file."+err);
			}
			////console.log("File uploaded");
			res.end("success");
		});
	}catch(err)
	{
		logger.error("NPMServer:Failed to upload License file."+err);
	}
});




app.get('/api/SysLog',function(req,res)
{
	try
	{
		var today = new Date();
		var browser="";
		var dateTimeS="_"+today.getFullYear()+""+(today.getMonth()+1)+""+today.getDate()+""+today.getHours()+""+today.getMinutes()+""+today.getSeconds();
		////console.log(dateTimeS);
		var query = url.parse(req.url, true).query;
		
		if(typeof query.operationtype === 'undefined')
		{
			//specify Content will be an attachment
			res.end("-1");
		}

		
		var operationType=query.operationtype;
		var path= "//var//volatile//log/";
		
		////console.log("operationType:"+operationType);
		
		  var dir = '//var//volatile//log//Logs';
		

		if (fsx.existsSync(dir)){
				fsx.removeSync(dir);	
			}
		   fsx.mkdirSync(dir);

		var fileArray = [];

		var list= fs.readdirSync(path);
		
			 
			  for (var i in list) 
			  {
			  
				var file=list[i];
				if (fs.statSync(path  + file).isDirectory()) 
				{
					////console.log(file + ": is a directory");
				} 
				else 
				{
					////console.log(file + ": is a file");
					fileArray.push(file);

				  }
		
			  }
		
			////console.log(path);
			////console.log(operationType);
			
			if(operationType==0 || operationType==2)
			{		
				var fileNameStartsWith="";
				if(operationType==0)
					fileNameStartsWith="messages";
				else
					fileNameStartsWith="MotCSD";
				
				
				var fileCount=0;
				var logFile="";
				
				for (var i = 0, len = fileArray.length; i < len; i++) 
				{
						//someFn(arr[i]);
						var f=fileArray[i];
						if(f.indexOf(fileNameStartsWith, 0)>-1)
									  {
										   //console.log(f + ": is a log file");
										   logFile=f;
										   
										  try {
												fsx.copySync(path+f, dir+"/"+f)
													////console.log('copied!');
													fileCount++;
											} catch (err) {
												logger.error("NPMServer:"+err);
												
												}

									  }	
						
				}
				
				if(fileCount>1)
				{
					var tarFileName=fileNameStartsWith+dateTimeS+'.tar';
					var dirDest = fs.createWriteStream(path+'/'+tarFileName)


					function onError(err) {
						res.writeHead(400, {'Content-type':'text/html'});
						////console.log('An error occurred while packing file:'+err);
						logger.error("NPMServer:An error occurred while packing file."+err);
						res.end('An error occurred while packing file:'+err);  
					  
					  
					}

					function onEnd() {
					  ////console.log('Packed!')
					   if (fs.existsSync(path+'/'+tarFileName)) 
					   {
								res.end(tarFileName);
						}else
							{
								res.writeHead(400, {'Content-type':'text/html'});
								////console.log("Log file "+ tarFileName +" does not exist.");
								logger.error("NPMServer:Log file "+ tarFileName +" does not exist.");
								res.end("Log file "+ tarFileName +" does not exist."); 
							}
						   
					  res.end(tarFileName);
					  
					}

					var packer = tar.Pack({ noProprietary: true })
					  .on('error', onError)
					  .on('end', onEnd);

					// This must be a "directory"
					fstream.Reader({ path: dir, type: "Directory" })
					  .on('error', onError)
					  .pipe(packer)
					  .pipe(dirDest)
				
				
				}else if(fileCount==1)
				{
						
						  
						  if (fs.existsSync(path+'/'+logFile)) 
						  {
									logger.error(path+'/'+logFile);
								res.end(logFile);
							}else
							{
								res.writeHead(400, {'Content-type':'text/html'});
								////console.log("Log file "+ logFile +" does not exist.");
								logger.error("NPMServer:Log file "+ logFile +" does not exist.");
								res.end("Log file does not exist."); 
							}
						  
					
				}else
				{
						res.writeHead(400, {'Content-type':'text/html'});
						res.end("Log files does not exists."); 
						logger.error("NPMServer:Log file(s) does not exists.");
					
				}
				
				
				
				
			}
			else if(operationType==1)//for filteredsyslog
			{
				
					if (fs.existsSync(path + 'filteredSyslog')) 
					{
						res.end("filteredSyslog");
					}else
					{
						res.writeHead(400, {'Content-type':'text/html'});
						logger.error("NPMServer:Log file filteredSyslog does not exist.");
						res.end("Log file filteredSyslog does not exist."); 
					}			
				
			}else
			{
						res.writeHead(400, {'Content-type':'text/html'});
						res.end("Log file does not exist.");    
						logger.error("NPMServer:FilteredSyslog does not exists.");
			}
			
	    //get the file list 
	}catch(err)
	{
		logger.error("NPMServer:Error while getting log file(s) information."+err);
		res.writeHead(400, {'Content-type':'text/html'});
		res.end("Error while getting log file(s) information.");
		
	}
});



app.get('/api/DownloadSysLog2', function (req, res) {
    try {
        var today = new Date();
        var browser = "";
        var FileName = "";
        var dir = '//var//volatile//log//Logs';
        var path = "//var//volatile//log/";

        var dateTimeS = "_" + today.getFullYear() + "" + (today.getMonth() + 1) + "" + today.getDate() + "" + today.getHours() + "" + today.getMinutes() + "" + today.getSeconds();
        ////console.log(dateTimeS);
        var query = url.parse(req.url, true).query;

        if (typeof query.filename === 'undefined') {
            //specify Content will be an attachment
            res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
            logger.error("NPMServer:filename undefined");
            res.end("filename undefined");

        } else if (query.filename.includes("/") || query.filename.includes("..")) {
            //specify Content will be an attachment
            res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
            logger.error("NPMServer: Invalid file name!");
            res.end("Invalid file name : Invalid file name!");
        } else {
            var FileName = query.filename.replace(/^.*[\\\/]/, '');
            if (FileName == '') {
                res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
                logger.error("NPMServer: Invalid file name!");
                res.end("Invalid file name : Invalid file name!");
            }
            else {
                //read the image using fs and send the image content back in the response
                fs.readFile(path + '/' + FileName, function (err, content) {
                    if (err) {
                        res.writeHead(400, { 'Content-Type': 'application/x-compressed' });
                        logger.error("NPMServer:Error while reading file:" + err);
                        res.end("Error while reading file:" + err);
                    } else {
                        if (!(FileName.indexOf(".tar") > -1))
                            FileName = FileName + dateTimeS;

                        //specify Content will be an attachment
                        res.setHeader('Content-disposition', 'attachment; filename=' + FileName);
                        res.end(content);


                        if (fsx.existsSync(dir)) {
                            // //console.log("removing....");
                            fsx.removeSync(dir);
                        }

                        if (FileName.indexOf(".tar") > -1) {
                            if (fsx.existsSync(path + '/' + FileName)) {
                                ////console.log("removing....");
                                fsx.removeSync(path + '/' + FileName);
                            }
                        }

                    }
                });
            }



        }

    } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/x-compressed' });
        logger.error(err);
        ////console.log('Error while downloading file.'+err);
        res.end('Error while downloading file.' + err);
    }

});

process.on('SIGINT', () => {
    logger.info("ReadTagServer received SIGINT");
    StreamEnginSocket.write('disconnect2\r\n');
    server.close();
    StreamEnginSocket.destroy();
    StreamEnginDataSocket.destroy();
    process.kill(process.pid, 'SIGTERM');
});


app.get('/api/profile', function (req, res) {

    try {
        var query = url.parse(req.url, true).query;
        if (typeof query.filename === 'undefined') {
            //specify Content will be an attachment
            res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
            logger.error("NPMServer:profile filename undefined");
            res.end("filename undefined");
        } else if (query.filename.includes("/") || query.filename.includes("..")) {
            //specify Content will be an attachment
            res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
            logger.error("NPMServer: Invalid file name!");
            res.end("Invalid file name : Invalid file name!");
        } else {

            var FileName = query.filename.replace(/^.*[\\\/]/, '');
            if (FileName == '') {
                res.writeHead(400, { 'Content-Type': 'application/x-compressed' })
                logger.error("NPMServer: Invalid file name!");
                res.end("Invalid file name : Invalid file name!");
            }
            else {


                var path = "//var//volatile//tmp";
                fs.readFile(path + '/Profiletmpfile.xml', function (err, content) {
                    if (err) {
                        res.writeHead(400, { 'Content-Type': 'application/x-compressed' });
                        logger.error("NPMServer:Error while reading file:" + err);
                        res.end("Error while reading file:" + err);
                    } else {
                        //specify Content will be an attachment
                        res.setHeader('Content-disposition', 'attachment; filename=' + FileName);
                        res.end(content);

                    }
                });
            }
        }


    } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/x-compressed' });
        logger.error(err);
        ////console.log('Error while downloading file.'+err);
        res.end('Error while downloading file.' + err);
    }

});

const WebSocket = require('ws');
const wsMaxConn = 1;

//WS close status codes
const wsConnError = {code: 3000, reason: "IOTC not running"}; //returned when connection to IOTC cannot be established.
const wsUnkownError = {code: 4000, reason:"Unknown Error"}; //returned when an unknown error occurs
const wsDisconnError = {code: 3001, reason: "IOTC disconnected"}; // IOTC disconnected.
const wsConnEndError = {code: 3002, reason: "IOTC Connection ended"}; //IOTC connection ended
const wsMaxConnError = {code: 3003, reason: "Max connections exceeded"}; //returned when the connection limit is exceeded.

class ws_tcp_bridge {

	constructor(){
		console.log("constructor");
		this.iotc_socket = new net.Socket();
		this.ws_server = new WebSocket.Server({ port: 8080 , host: 'localhost'}); 
		this.ws_server.on('connection', this.on_ws_connection.bind(this));
		this.numConnections=0;
		console.log("constructor done");
	}

	on_ws_connection(ws){
			console.log("WS Client Connection request received");
			logger.info("WS Client Connection request received");
			this.ws = ws;
			this.ws.on('message', this.on_ws_message.bind(this));
			this.iotc_socket.on('error', this.on_iotc_error.bind(this));
			this.iotc_socket.on('disconnect', this.on_iotc_disconnect.bind(this));
			this.iotc_socket.on('close', this.on_iotc_close.bind(this));
			this.iotc_socket.on('end', this.on_iotc_end.bind(this));
			this.iotc_socket.on('data', this.on_iotc_data.bind(this));
			this.iotc_socket.on('connect_error', this.on_iotc_connect_error.bind(this));
			this.iotc_socket.connect(8051, "localhost", this.on_iotc_connect.bind(this));
			this.iotc_socket.setKeepAlive(5000);
			if(this.numConnections == wsMaxConn){
				this.ws.close(wsMaxConnError.code, wsMaxConnError.reason);
				return;
			}			
			this.numConnections++;
	}

	on_ws_message(message){
		console.log("WS Client Connection mesg received");
		//This function is only for testing the ws send recv and not used in production
		this.ws.send('Hi, you sent me ' + message);
	}

	on_iotc_connect_error(){
		console.log("Could not establish connection to IOTC TCP socket.");
		logger.error("Could not establish connection to IOTC TCP socket.");
		if (this.ws.readyState !== WebSocket.CLOSED) {
			this.ws.close(wsConnError.code, wsConnError.reason);
			this.numConnections--;
		}		
	}

	on_iotc_connect(){
		logger.info("ReadTagServer:Node Connected to iotc TCP socket.");
		console.log("ReadTagServer:Node Connected to iotc TCP socket.");
	}

	on_iotc_error(ex){
		logger.error("ReadTagServer:Error in Node Connection to iotc TCP socket. " + ex);
		console.log("ReadTagServer:Error in Node Connection to iotc TCP socket. " + ex);
		if (this.ws.readyState !== WebSocket.CLOSED) {
			this.ws.close(wsUnkownError.code, wsUnkownError.reason + ":" + JSON.stringify(ex));
			this.numConnections--;
		}
	}

	on_iotc_disconnect(){
		logger.info("ReadTagServer: Disconnected from iotc tcp socket.");
		console.log("ReadTagServer: Disconnected from iotc tcp socket.");
		if (this.ws.readyState !== WebSocket.CLOSED) {
			this.ws.close(wsDisconnError.code, wsDisconnError.reason);
			this.numConnections--;
		}		
	}

	on_iotc_end(){
		logger.info("ReadTagServer: Ended from iotc tcp socket.");
		console.log("ReadTagServer: Ended from iotc tcp socket.");
		if (this.ws.readyState !== WebSocket.CLOSED) {
			this.ws.close(wsConnEndError.code, wsConnEndError.reason);
			this.numConnections--;
		}
	}

	on_iotc_close(){
		logger.info("ReadTagServer: Closed iotc tcp socket.");
		console.log("ReadTagServer: Closed iotc tcp socket.");
	}

	on_iotc_data(data){
		this.ws.send(data);
	}

	destructor(){
		logger.info("ws_tcp_bridge destructor called.");
		console.log("ws_tcp_bridge destructor called.");
		this.iotc_socket.destroy();
	}
}

const wsTcpBridge = new ws_tcp_bridge();
