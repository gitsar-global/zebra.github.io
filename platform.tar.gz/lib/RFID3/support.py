import logging
import sys

from RFID3.constants import RFID_STATUS, RFID_STATUS_INV


def GetLogger():
    """sets logger"""
    EVENT = 25
    logging.addLevelName(EVENT, 'EVENT')
    log = logging.getLogger()
    log.event = lambda msg, *args: log._log(EVENT, msg, args)
    log.setLevel(logging.CRITICAL)

    # setting handler
    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(logging.CRITICAL)
    # setting formatter
    formatter = logging.Formatter(
        fmt='%(asctime)s %(name)-10.10s%(levelname)-9s %(message)s', datefmt='%m/%d %I:%M:%S %p')
    handler.setFormatter(formatter)

    log.addHandler(handler)

    return log


# logger
log = GetLogger()


# verify rfid api response status
def VerifyStatus(status, log_=True):
    """verify api status"""
    if status == RFID_STATUS['RFID_API_SUCCESS']:
        if log_:
            log.info("api status: success")
        return True
    else:
        if log_:
            log.error("api status: failed with status {}".format(
                RFID_STATUS_INV[status]))
        return False
