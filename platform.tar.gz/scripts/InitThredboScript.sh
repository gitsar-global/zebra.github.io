#!/bin/bash
#
# thredbo	Execute the all required startup applications/commands.
#
# Version:      @(#)thredbo  1.1.0.3 10/23/2013
#

# set the path of addition library folder as /platform/lib
export LD_LIBRARY_PATH=/usr/local/avahi/lib:/platform/lib:/usr/local/bluetooth/lib:$LD_LIBRARY_PATH
export PATH=$PATH:/usr/local/bluetooth/bin:/usr/local/bluetooth/sbin:/usr/local/avahi/sbin

#Environment Settings For Java Runtime.
export JAVA_HOME=/usr/local/jvm/icedtea-openjdk-oe-core-jre
export PATH=$PATH:$JAVA_HOME/bin
export CLASSPATH=/platform/lib/Symbol.RFID.API3.jar

# Set PYTHONHOME before staring Apache
export PYTHONHOME=/

DEFAULT_FILES=$(ls /platform/config/)

NAME=InitThredboScript.sh

function copy_def_files()
{
	if [ -f /platform/config/$1 ];then
		if [ ! -f /readerconfig/$1 ];then 
			cp /platform/config/$1 /readerconfig/$1
		fi
	elif [ -d /platform/config/$1 ];then
		if [ ! -e /readerconfig/$1 ];then
			mkdir /readerconfig/$1
		fi

		SUB_DIR_FILES=$(ls /platform/config/$1)
		for file in $SUB_DIR_FILES
		do
			FILE=$1/${file}
			copy_def_files $FILE
		done
	fi		 

}

function restore_defaults()
{
	for file in $DEFAULT_FILES
	do
		copy_def_files ${file}
	done
}

function start_networking()
{
	
	# Set the Networking Services
	/etc/init.d/networking start

	#Start Auto connect Wifi script
	if [ -f /readerconfig/autoconnect.sh ]; then
		echo "Starting wirless network....."
		/readerconfig/autoconnect.sh &
	fi

	#Execute n/w script from /readerconfig
	#if [ -f /readerconfig/networkscript.sh ];then 
	#	/readerconfig/networkscript.sh
	#fi

	#Command to get the APIPA IP @ startup
	/platform/bin/startavahi.elf

	/platform/bin/readerinit.elf

	#Add RNDIS IP address //this is moved to start_udev
	#ifconfig usb0 169.254.10.1 netmask 255.255.255.0 up


	#Start the run time IP script
	/platform/scripts/dynamic-nw-IP.sh &

	#start the DHCP server for usb0 interface //this is moved to start_udev
	#touch /var/run/dhcpd.leases
	#/usr/local/dhcpv6/dhcpd -4 -cf /platform/config/dhcpd.conf -lf /var/run/dhcpd.leases usb0 &

}



function mount_partitions()
{
	# mount the platform mtd
	#/bin/mountplatform.elf
	if [ -e /proc ] && ! [ -e /proc/mounts ]; then
		mount -t proc proc /proc
	fi

	if [ -e /sys ] && grep -q sysfs /proc/filesystems; then
		mount sysfs /sys -t sysfs
	fi

	echo "mounting tmpfs on /var/volatile"
	mount -t tmpfs tmpfs /var/volatile
	RET=$?
	if [ $RET != 0 ];then
		echo "mount tmpfs on /var/volatile failed"
	fi
	
	if [ ! -d /dev/shm ];then
		mkdir /dev/shm
	fi

	echo "mounting tmpfs on /dev/shm"
	mount -t tmpfs tmpfs /dev/shm
	RET=$?
	if [ $RET != 0 ];then
		echo "mount tmpfs on /dev/shm failed"
	fi

	echo "mounting tmpfs on /media/ram"
	mount -t tmpfs tmpfs /media/ram	
	RET=$?
	if [ $RET != 0 ];then
		echo "mount tmpfs on /media/ram fialed"
	fi 

	# Call mfgreset. Maintain the sequence of calling mfgreset 
	# before mounting readerconfig.
	chmod +x /platform/bin/mfgreset.elf
	/platform/bin/mfgreset.elf
	chmod -x /platform/bin/mfgreset.elf

	# create /mnt/readerconfig if not available
	if [ ! -d /mnt/readerconfig ]; then
		echo "/mnt/readerconfig missing.."
	fi
	
	# mount readerconfig partition
	mount -t jffs2 /dev/mtdblock12 /mnt/readerconfig

	# create /mnt/data if not available
	if [ ! -d /mnt/data ]; then
		echo "/mnt/data missing"
	fi
	
	# mount data partition
	mount -t jffs2 /dev/mtdblock15 /mnt/data
	
	if [ ! -d /dev/pts ];then
		mkdir /dev/pts
	fi

	mount -t devpts devpts /dev/pts
	RET=$?
	if [ $RET != 0 ];then
		echo "devpts mount failed"
	fi 
	
	mount -t tmpfs tmpfs /tmp
	RET=$?
	if [ $RET != 0 ];then
		echo "tmpfs on tmp failed"
	fi
}

function fix_permissions()
{
	chgrp -R appsadms /apps
	chmod -R g+rwx /apps

	#provide +x permissions to /platform/bin
	chmod +x -R /platform/bin/
	chmod +x -R /platform/scripts
	chmod o-w -R /platform/

	if [ ! -s /usr/local/samba/var ];then
		echo "ERROR: /usr/local/samba/var not a symbolic link"
	else
		#samba directories
		mkdir /var/lib/samba/nmbd
		chown root:root /var/lib/samba/nmbd
		mkdir /var/lib/samba/locks
	fi
	# provide 0600 permission to racoon passkey file
	chmod 0600 /platform/config/psk.txt
}


function init()
{	
	#start the readerinit app (not a daemon)
	/platform/bin/readerinit.elf
}

function start_services()
{

	/etc/init.d/sysklogd start &

	mkdir -p /var/volatile/lib/bluetooth
	mkdir -p /var/volatile/lib/dbus
	mkdir -p /var/volatile/run/dbus
	mkdir -p /var/volatile/empty

	#start dbus
	/etc/init.d/dbus-1 start

	#start bluetooth //this is moved to start_udev
	#/etc/init.d/bluetooth start &

	# Start apache server
	/usr/sbin/restart.sh

	#Start SNMP Master Agent
	/usr/local/snmp/sbin/snmpd &

	#Start SNMP Ext Agent
	/platform/bin/snmpextagent.elf &

	# Start LLRP
	/platform/bin/llrpserver.elf -p /dev/ttyO1 &

	# Start RMServer
	PATH=$PATH:/usr/local/bluetooth/bin:/usr/local/bluetooth/sbin LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/bluetooth/lib platform/bin/rmserver.elf &

	#set the key for IPSec
	setkey -f /etc/ipsec-tools/setkey.conf
	
	#start racoon for IPSec
	racoon -f /etc/ipsec-tools/racoon.conf -l /dev/null &

	#start ftp server, vsftpd
	#/usr/sbin/vsftpd &
	#start nmbd (netbios)
	/usr/sbin/nmbd &

	#Start RDMP. No & required as process now executes as daemon
	#RDMP start has been moved to dynamic-nw-IP script
}



function start_userapps()
{
	if [ -e /apps/autostart.sh ];then 
		#Start user applications
		echo "Starting applications...."
		chmod +x /apps/autostart.sh
		su -c '/apps/autostart.sh &' rfidadm
	fi
	if [ -e /apps/trusted/autostart.sh ];then 
		#Start user applications
		echo "Starting trusted applications...."
		chmod +x /apps/trusted/autostart.sh
		su -c '/apps/trusted/autostart.sh &' trfidadm
	fi
}


function run_init_scripts()
{
	#udev requires to have a file /readerconfig/modules.dep
	#create it if it does not exist initially
	touch /readerconfig/modules.dep
	#/etc/init.d/devices //we are mounting devtmpfs no need to poplate devices
	#/etc/init.d/udev //moved to start_udev
	/etc/init.d/populate-volatile.sh 
	sysctl -q -p /etc/sysctl.conf
	

}
function start_udev
{
	/etc/init.d/udev & 
	#load EHCI driver 
	#insmod /lib/modules/ehci-hcd.ko
	#start bluetooth
	/etc/init.d/bluetooth start &

	#Add RNDIS IP address
	ifconfig usb0 169.254.10.1 netmask 255.255.255.0 up

	#start the DHCP server for usb0 interface
	touch /var/run/dhcpd.leases
	/usr/local/dhcpv6/dhcpd -4 -cf /platform/config/dhcpd.conf -lf /var/run/dhcpd.leases usb0 &
	/platform/bin/usbHealth.elf &
}

case "$1" in
  start)
    echo "Executing thredbo startup script..."
    echo "===================================="
    mount_partitions
    fix_permissions
    restore_defaults $DEFAULT_FILES
    run_init_scripts
    start_networking
    #init
    start_services
    start_userapps
    start_udev	
  ;;
  stop)
  
  ;;
  restart)
  ;;
  *)
    echo "Usage: /etc/init.d/$NAME {start|stop|restart}" >&2
  ;;
esac



