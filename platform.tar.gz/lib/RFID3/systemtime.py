import datetime

from rfidapi32py import ffi


class SystemTime:

    @staticmethod
    def GetLocalTime():
        """
        Current system time
        :return: SystemTime struct
        """
        startTime = ffi.new("SYSTEMTIME *")
        now = datetime.datetime.now()
        startTime.wYear = now.year
        startTime.wMonth = now.month
        startTime.wDayOfWeek = datetime.datetime.today().weekday()
        startTime.wDay = now.day
        startTime.wHour = now.hour
        startTime.wMinute = now.minute
        startTime.wSecond = now.second
        startTime.wMilliseconds = 0
        return startTime

    @staticmethod
    def GetSystemTime(wYear=None, wMonth=None, wDayOfWeek=None, wDay=None, wHour=None, wMinute=None, wSecond=None, wMilliseconds=None):
        """
        get system time
        :return: SYSTEMTIME struct
        """
        startTime = ffi.new("SYSTEMTIME *")
        startTime.wYear = wYear
        startTime.wMonth = wMonth
        startTime.wDayOfWeek = wDayOfWeek
        startTime.wDay = wDay
        startTime.wHour = wHour
        startTime.wMinute = wMinute
        startTime.wSecond = wSecond
        startTime.wMilliseconds = wMilliseconds
        return startTime
