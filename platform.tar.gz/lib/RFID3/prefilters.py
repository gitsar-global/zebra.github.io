from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class MEMORY_BANK:
    MEMORY_BANK_RESERVED = 0
    MEMORY_BANK_EPC = 1
    MEMORY_BANK_TID = 2
    MEMORY_BANK_USER = 3


class FILTER_ACTION:
    FILTER_ACTION_DEFAULT = 0
    FILTER_ACTION_STATE_AWARE = 1
    FILTER_ACTION_STATE_UNAWARE = 2


class STATE_UNAWARE_ACTION:
    STATE_UNAWARE_ACTION_SELECT_NOT_UNSELECT = 0x00
    STATE_UNAWARE_ACTION_SELECT = 0x01
    STATE_UNAWARE_ACTION_NOT_UNSELECT = 0x02
    STATE_UNAWARE_ACTION_UNSELECT = 0x03
    STATE_UNAWARE_ACTION_UNSELECT_NOT_SELECT = 0x04
    STATE_UNAWARE_ACTION_NOT_SELECT = 0x05


class TARGET:
    TARGET_SL = 0
    TARGET_INVENTORIED_STATE_S0 = 1
    TARGET_INVENTORIED_STATE_S1 = 2
    TARGET_INVENTORIED_STATE_S2 = 3
    TARGET_INVENTORIED_STATE_S3 = 4


class STATE_AWARE_ACTION:

    STATE_AWARE_ACTION_INV_A_NOT_INV_B = 0x00
    STATE_AWARE_ACTION_ASRT_SL_NOT_DSRT_SL = 0x00

    STATE_AWARE_ACTION_INV_A = 0x01
    STATE_AWARE_ACTION_ASRT_SL = 0x01

    STATE_AWARE_ACTION_NOT_INV_B = 0x02
    STATE_AWARE_ACTION_NOT_DSRT_SL = 0x02

    STATE_AWARE_ACTION_INV_A2BB2A = 0x03
    STATE_AWARE_ACTION_INV_A2BB2A_NOT_INV_A = 0x03

    STATE_AWARE_ACTION_NEG_SL = 0x03
    STATE_AWARE_ACTION_NEG_SL_NOT_ASRT_SL = 0x03

    STATE_AWARE_ACTION_INV_B_NOT_INV_A = 0x04
    STATE_AWARE_ACTION_DSRT_SL_NOT_ASRT_SL = 0x04

    STATE_AWARE_ACTION_INV_B = 0x05
    STATE_AWARE_ACTION_DSRT_SL = 0x05

    STATE_AWARE_ACTION_NOT_INV_A = 0x06
    STATE_AWARE_ACTION_NOT_ASRT_SL = 0x06

    STATE_AWARE_ACTION_NOT_INV_A2BB2A = 0x07
    STATE_AWARE_ACTION_NOT_NEG_SL = 0x07


class FilterActionParams:

    def __init__(self, filterAction):

        if filterAction == FILTER_ACTION.FILTER_ACTION_STATE_AWARE:
            self.target = None
            self.stateAwareAction = None
        elif filterAction == FILTER_ACTION.FILTER_ACTION_STATE_UNAWARE:
            self.stateUnawareAction = None


class Filter:

    def __init__(self):
        self._memoryBank = None
        self._tagPatternBitCount = None
        self._filterMask = ffi.new("unsigned char[32]")
        self._bitOffset = None
        self._filterAction = None
        self.filterActionParams = None

    @property
    def memoryBank(self):
        if self._memoryBank is None:
            return MEMORY_BANK.MEMORY_BANK_EPC
        else:
            return self._memoryBank

    @memoryBank.setter
    def memoryBank(self, value):
        if value not in [0, 1, 2, 3]:
            raise Exception("Memory Bank not available")
        else:
            self._memoryBank = value

    @property
    def tagPatternBitCount(self):
        if self._tagPatternBitCount is None:
            return 16
        else:
            return self._tagPatternBitCount

    @tagPatternBitCount.setter
    def tagPatternBitCount(self, value):
        self._tagPatternBitCount = value

    @property
    def pTagPattern(self):
        return self._filterMask

    @pTagPattern.setter
    def pTagPattern(self, pattern):

        for j in range(int((self.tagPatternBitCount + 7) / 8)):
            hex_lst = [pattern[k:k + 2] for k in range(0, len(pattern), 2)]
            self._filterMask[j] = int(hex_lst[j], 16)

    @property
    def bitOffset(self):
        if self._bitOffset is None:
            return 32
        else:
            return self._bitOffset

    @bitOffset.setter
    def bitOffset(self, value):
        self._bitOffset = value

    @property
    def filterAction(self):
        return self._filterAction

    @filterAction.setter
    def filterAction(self, value):
        if value not in [0, 1, 2]:
            raise Exception("Filter Action not available")
        else:
            self._filterAction = value
            self.filterActionParams = FilterActionParams(self._filterAction)


# noinspection PyMethodMayBeStatic
class PreFilters:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle
        self.max_prefilters = 0
        self.prefilters_set = 0
        self.last_filter_index = None

    def _Add(self, mask, antennas):
        """
        Adding prefilters
        :param antennas:
        :param mask:
        :return:
        """
        filter = ffi.new("PRE_FILTER[2]")
        filterMask0 = ffi.new("unsigned char[32]")
        filterMask1 = ffi.new("unsigned char[32]")
        antennaID = ffi.new("unsigned short *")
        Index = ffi.new("unsigned int *")
        filter[0].pTagPattern = filterMask0
        filter[1].pTagPattern = filterMask1

        if self.prefilters_set >= self.max_prefilters:
            log.error("max prefilters reached")
            return False

        filter[0].memoryBank = int(mask[0])
        pBytes = str(mask[4])
        filter[0].tagPatternBitCount = int(mask[2])

        for j in range(int((filter[0].tagPatternBitCount + 7) / 8)):
            hex_lst = [pBytes[k:k + 2] for k in range(0, len(pBytes), 2)]
            filter[0].pTagPattern[j] = int(hex_lst[j], 16)

        filter[0].bitOffset = int(mask[1])
        filter[0].filterAction = int(1)
        filter[0].filterActionParams.stateAwareParams.target = int(0)
        filter[0].filterActionParams.stateAwareParams.stateAwareAction = int(1)

        for i in range(0, len(antennas)):
            antennaID[0] = antennas[i]
            status = lib.RFID_AddPreFilter(
                self.reader_handle, antennaID[0], filter, Index)
            if not VerifyStatus(status):
                return False
        return True

    def Add(self, filter, antenna):

        pre_filter = self.formFilter(filter)

        antennaID = ffi.new("unsigned short *")
        antennaID[0] = antenna

        Index = ffi.new("unsigned int *")

        status = lib.RFID_AddPreFilter(
            self.reader_handle, antennaID[0], pre_filter, Index)
        if not VerifyStatus(status):
            self.last_filter_index = None
            return False

        self.last_filter_index = Index[0]
        self.prefilters_set += 1
        return True

    def Remove(self, index, antenna):
        """
        Removes pre filter
        :param index: filter index
        :param antenna: antenna id
        :return: True if success else False
        """
        assert isinstance(index, int), log.error("expected index to be int")
        assert isinstance(antenna, int), log.error("expected index to be int")

        log.info("removing pre filter {}".format(index))
        filter_index = ffi.new("unsigned int *")
        filter_index[0] = index

        status = lib.RFID_DeletePreFilter(
            self.reader_handle, antenna, filter_index[0])
        if VerifyStatus(status):
            log.info("remove pre filter api success")
            self.prefilters_set -= 1
            return True
        else:
            log.error("remove pre filter api failed")
            return False

    def formFilter(self, FilterObj):

        pre_filter = ffi.new("PRE_FILTER[1]")

        pre_filter[0].memoryBank = FilterObj.memoryBank
        pre_filter[0].tagPatternBitCount = FilterObj.tagPatternBitCount
        pre_filter[0].pTagPattern = FilterObj.pTagPattern
        pre_filter[0].bitOffset = FilterObj.bitOffset

        if FilterObj.filterAction == FILTER_ACTION.FILTER_ACTION_STATE_AWARE:
            pre_filter[0].filterAction = FilterObj.filterAction
            pre_filter[0].filterActionParams.stateAwareParams.target = FilterObj.filterActionParams.target
            pre_filter[0].filterActionParams.stateAwareParams.stateAwareAction = FilterObj.filterActionParams.stateAwareAction
        elif FilterObj.filterAction == FILTER_ACTION.FILTER_ACTION_STATE_UNAWARE:
            pre_filter[0].filterAction = FilterObj.filterAction
            pre_filter[0].filterActionParams.stateUnawareAction = FilterObj.filterActionParams.stateUnawareAction
        else:
            pre_filter[0].filterAction = FILTER_ACTION.FILTER_ACTION_STATE_AWARE
            pre_filter[0].filterActionParams.stateAwareParams.target = TARGET.TARGET_SL
            pre_filter[0].filterActionParams.stateAwareParams.stateAwareAction = STATE_AWARE_ACTION.STATE_AWARE_ACTION_INV_A

        return pre_filter
