from rfidapi32py import ffi

from RFID3.constants import TAG_EVENT


class TagData:
    """Tag Data class"""

    def __init__(self, pTagData):
        if pTagData:
            self.antennaID = int(pTagData.antennaID)

            # Read First and last seen time stamp
            localtime = pTagData.seenTime.utcTime.firstSeenTimeStamp if pTagData.tagEvent == TAG_EVENT[
                'NONE'] else pTagData.tagEventTimeStamp
            self.firstSeenTimeStamp = "%04d-%02d-%02dT%02d:%02d:%02d.%03dZ" % (
                localtime.wYear, localtime.wMonth, localtime.wDay, localtime.wHour, localtime.wMinute, localtime.wSecond, localtime.wMilliseconds)
            localtime = pTagData.seenTime.utcTime.lastSeenTimeStamp if pTagData.tagEvent == TAG_EVENT[
                'NONE'] else pTagData.tagEventTimeStamp
            self.lastSeenTimeStamp = "%04d-%02d-%02dT%02d:%02d:%02d.%03dZ" % (
                localtime.wYear, localtime.wMonth, localtime.wDay, localtime.wHour, localtime.wMinute, localtime.wSecond, localtime.wMilliseconds)

            self.PC = "%5x" % pTagData.PC
            self.phaseInfo = pTagData.phaseInfo
            self.peakRSSI = pTagData.peakRSSI
            #epc = "".join("{:02x}".format(int(ffi.cast('char', c))) for c in pTagData.pTagID[0:pTagData.tagIDLength])
            #self.EPC = ':'.join(epc[i:i + 4] for i in range(0, len(epc), 4))
            self.EPC = (ffi.buffer(
                pTagData.pTagID[0:pTagData.tagIDLength])[:]).hex()
            self.TagType = 'GS1'  # todo: add logic to find the type of tag

            # Read Tag seen count
            self.tagSeenCount = pTagData.tagSeenCount

    def __str__(self):
        return "Tag Data:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))
