PID=`ps -ef |grep sshd | awk '{print $2}'`
for i in $PID; do echo "killing telnet session process with PID = $i"; 
sleep 1;
kill -9 $PID;
done
