import time
from queue import Queue
from threading import Thread

from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus
from RFID3.constants import RFID_EVENT_TYPES

# event queue
StatusEventQueue = Queue()
ReadEventQueue = Queue(maxsize=1000)


@ffi.def_extern()
def rfidEventCallback(readerhandle, event_type):
    """Event callback handler"""
    global StatusEventQueue, ReadEventQueue
    StatusEventQueue.put(event_type)


# noinspection PyMethodMayBeStatic
class Event:
    """Event class to handle RFIDAPI3 events"""

    MAX_EVENTS = 12

    def __init__(self, reader_handle):

        self.reader_handle = reader_handle
        # event handler thread variables
        self.stop_event_handler = True
        self.event_handler = None

        # user callback
        self.callback = None
        self.callback_events = set()

    @property
    def gpi_event(self):
        """
        gpi event
        :return: None
        """
        event = RFID_EVENT_TYPES['GPI_EVENT']
        return event in self.callback_events

    @gpi_event.setter
    def gpi_event(self, flag):
        """
        gpi event
        :return: None
        """
        event = RFID_EVENT_TYPES['GPI_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def tag_data_event(self):
        """
        tag_data_event
        :return: None
        """
        event = RFID_EVENT_TYPES['TAG_DATA_EVENT']
        return event in self.callback_events

    @tag_data_event.setter
    def tag_data_event(self, flag):
        """
        tag_data_event
        :return: None
        """
        event = RFID_EVENT_TYPES['TAG_DATA_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def buffer_full_event(self):
        """
        buffer_full_event
        :return: None
        """
        event = RFID_EVENT_TYPES['BUFFER_FULL_EVENT']
        return event in self.callback_events

    @buffer_full_event.setter
    def buffer_full_event(self, flag):
        """
        buffer_full_event
        :return: None
        """
        event = RFID_EVENT_TYPES['BUFFER_FULL_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def buffer_full_warning_event(self):
        """
        buffer_full_warning_event
        :return: None
        """
        event = RFID_EVENT_TYPES['BUFFER_FULL_WARNING_EVENT']
        return event in self.callback_events

    @buffer_full_warning_event.setter
    def buffer_full_warning_event(self, flag):
        """
        buffer_full_warning_event
        :return: None
        """
        event = RFID_EVENT_TYPES['BUFFER_FULL_WARNING_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def inventory_start_event(self):
        """
        inventory_start_event
        :return: None
        """
        event = RFID_EVENT_TYPES['INVENTORY_START_EVENT']
        return event in self.callback_events

    @inventory_start_event.setter
    def inventory_start_event(self, flag):
        """
        inventory_start_event
        :return: None
        """
        event = RFID_EVENT_TYPES['INVENTORY_START_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def inventory_stop_event(self):
        """
        inventory_stop_event
        :return: None
        """
        event = RFID_EVENT_TYPES['INVENTORY_STOP_EVENT']
        return event in self.callback_events

    @inventory_stop_event.setter
    def inventory_stop_event(self, flag):
        """
        inventory_stop_event
        :return: None
        """
        event = RFID_EVENT_TYPES['INVENTORY_STOP_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def reader_exception_event(self):
        """
        reader_exception_event
        :return: None
        """
        event = RFID_EVENT_TYPES['READER_EXCEPTION_EVENT']
        return event in self.callback_events

    @reader_exception_event.setter
    def reader_exception_event(self, flag):
        """
        reader_exception_event
        :return: None
        """
        event = RFID_EVENT_TYPES['READER_EXCEPTION_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    @property
    def disconnection_event(self):
        """
        disconnection_event
        :return: None
        """
        event = RFID_EVENT_TYPES['DISCONNECTION_EVENT']
        return event in self.callback_events

    @disconnection_event.setter
    def disconnection_event(self, flag):
        """
        disconnection_event
        :return: None
        """
        event = RFID_EVENT_TYPES['DISCONNECTION_EVENT']
        if flag:
            self.callback_events.add(event)
        else:
            if event in self.callback_events:
                self.callback_events.remove(event)

    def ExecuteCallBack(self, event):
        """
        Execute callback function registered by user
        :param event: event id
        :return: None
        """
        if event in self.callback_events:
            self.callback(event)

    def EventProcessorThread(self):
        """
        processes rfid events
        :return: None
        """
        global StatusEventQueue
        log.info("event processor thread started")
        while not self.stop_event_handler:

            event = StatusEventQueue.get()
            if callable(self.callback):
                self.ExecuteCallBack(event)

            # if event == RFID_EVENT_TYPES['INVENTORY_START_EVENT']:
            #     log.event("Inventory start")

            # elif event == RFID_EVENT_TYPES['INVENTORY_STOP_EVENT']:
            #     log.event("Inventory stop")

            # elif event == RFID_EVENT_TYPES['DISCONNECTION_EVENT']:
            #     log.event("Reader disconnected")

            # elif event == RFID_EVENT_TYPES['READER_EXCEPTION_EVENT']:
            #     log.event("Reader Exception")

            # elif event == RFID_EVENT_TYPES['GPI_EVENT']:
            #     log.event("GPI Event")

            # elif event == RFID_EVENT_TYPES['ANTENNA_EVENT']:
            #     log.event("Antenna Event")

            # elif event == RFID_EVENT_TYPES['TAG_DATA_EVENT']:
            #     log.event("Tag data event")
            #
            # elif event == RFID_EVENT_TYPES['BUFFER_FULL_EVENT']:
            #     log.event("Buffer full event")
            #
            # elif event == RFID_EVENT_TYPES['BUFFER_FULL_WARNING_EVENT']:
            #     log.event("Buffer full warning event")

        log.info("event processor thread stopped")

    def StartEventHandlerThread(self):
        """
        starts event handler thread
        :return: None
        """
        log.info("starting event handler thread.")
        if self.stop_event_handler:
            self.stop_event_handler = False
            self.event_handler = Thread(target=self.EventProcessorThread)
            self.event_handler.start()
        else:
            log.info("event handler thread already running.")

    def StopEventHandlerThread(self):
        """
        stop event handler thread
        :return: None
        """
        log.info("stopping event handler thread")
        self.stop_event_handler = True
        # timeout for thread to stop
        global StatusEventQueue
        StatusEventQueue.put('STOP')
        time.sleep(1)

    def RegisterCallback(self, cb):
        """
        register user callback for events
        :param cb: callback function user want to execute when events occur
        :return: True if success else False
        """
        if not callable(cb):
            log.error("callback function should be callable")
            return False
        self.callback = cb
        self.RegisterEventNotificationCallback()
        self.StartEventHandlerThread()

        return True

    def DeRegisterCallback(self):
        """
        De Register callback
        :return: None
        """
        self.callback = None
        self.gpi_event = False
        self.tag_data_event = False
        self.buffer_full_event = False
        self.buffer_full_warning_event = False
        self.inventory_start_event = False
        self.inventory_stop_event = False
        self.reader_exception_event = False
        self.disconnection_event = False

    def RegisterEventNotificationCallback(self):
        """
        Registers callback for events
        :return: True if success else False
        """
        log.info("registering event callback function")

        #event_types = ffi.new("RFID_EVENT_TYPE []", [v for v in RFID_EVENT_TYPES.values()])
        #status = lib.RFID_RegisterEventNotificationCallback(self.reader_handle, event_types, Event.MAX_EVENTS, lib.rfidEventCallback, ffi.NULL, ffi.NULL)

        event_types = ffi.new("RFID_EVENT_TYPE []", [
                              v for v in self.callback_events])
        status = lib.RFID_RegisterEventNotificationCallback(self.reader_handle, event_types, len(
            self.callback_events), lib.rfidEventCallback, ffi.NULL, ffi.NULL)
        return VerifyStatus(status)
