from rfidapi32py import ffi


class ReaderCapabilities:

    def __init__(self, cap_obj):
        self.firmWareVersion = ffi.string(cap_obj.firmWareVersion)
        self.modelName = ffi.string(cap_obj.modelName)
        self.serialNumber = ''
        for i in range(0, 17):
            self.serialNumber += cap_obj.readerID.value[i]
        self.numAntennas = cap_obj.numAntennas
        self.numGPIs = cap_obj.numGPIs
        self.numGPOs = cap_obj.numGPOs
        self.utcClockSupported = bool(cap_obj.utcClockSupported)
        self.blockEraseSupported = bool(cap_obj.blockEraseSupported)
        self.blockWriteSupported = bool(cap_obj.blockWriteSupported)
        self.stateAwareSingulationSupported = bool(
            cap_obj.stateAwareSingulationSupported)
        self.maxNumOperationsInAccessSequence = cap_obj.maxNumOperationsInAccessSequence
        self.maxNumPreFilters = cap_obj.maxNumPreFilters
        self.communicationStandard = cap_obj.communicationStandard
        self.countryCode = cap_obj.countryCode
        self.hoppingEnabled = bool(cap_obj.hoppingEnabled)
        self.receiveSensitivityRange = range(
            0, cap_obj.receiveSensitivtyTable.numValues - 1)
        self.readerID = ffi.string(cap_obj.readerID.value)

        if self.hoppingEnabled:
            self.freqIndexRange = range(1, cap_obj.freqHopInfo.numTables)
        else:
            self.freqIndexRange = range(1, cap_obj.fixedFreqInfo.numFreq)

        self.transmitPowerIndexRange = range(
            0, cap_obj.transmitPowerLevelTable.numValues - 1)

        self.PowerValueList = []
        for x in range(cap_obj.transmitPowerLevelTable.numValues):
            self.PowerValueList.append(
                cap_obj.transmitPowerLevelTable.pPowerValueList[x])

    def __str__(self):
        return "Reader Capabilities:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))
