"""
.. module:: reader
    :synopsis: It is an entry point for module ``RFIDReader()`` class is defined here.

.. moduleauthor:: Rahul Bachina <rbachina@zebra.com>
"""

from rfidapi32py import ffi, lib
from RFID3.support import log, VerifyStatus
from RFID3.action import Action
from RFID3.capabilities import ReaderCapabilities
from RFID3.configuration import Config
from RFID3.constants import RFID_VERSIONS, RFID_EVENT_TYPES
from RFID3.events import Event


# noinspection PyMethodMayBeStatic
class RFIDReader:
    """
    This is a class representation of a RFID reader.

    :param host: A unicode representation of reader ip address, defaults to ``u'127.0.0.1'``
    :type host: str

    :param port: Reader port number, defaults to ``0``
    :type port: int
    """

    def __init__(self, host=u'127.0.0.1', port=0):

        self.Host = host
        self.Port = port

        # reader handle
        self.Handle = None

        # Reader capabilities
        self.Capabilities = None

        # Event class object
        self.Event = None

        # Action class object
        self.Action = None
        # Config class object
        self.Config = None
        # init
        self.init = False

        self.Initialize()

    def __del__(self):
        self.DeInitialize()

    def Initialize(self):
        """
        initialize reader
        :return: None
        """
        log.info("initialize reader")
        status = self.Connect(self.Host, self.Port, 0)
        if not status:
            raise Exception("Failed to connect with reader.")
        self.SetTraceLevel()
        self.Action = Action(self.Handle)
        self.Event = Event(self.Handle)
        self.Action.AllocateTag()
        self.Config = Config(self.Handle)
        self.GetReaderCapabilities()
        self.init = True

    def DeInitialize(self):
        """
        de initialize reader
        :return: None
        """
        if self.init:
            log.info("deinitialize reader")
            self.Event.StopEventHandlerThread()
            self.Action.DeAllocateTag()
            self.Disconnect()
            self.init = False

    def Connect(self, host, port, timeout):
        """
        connects to reader with given host and port
        :param host: host ip
        :param port: port
        :param timeout: timeout
        :return: True if success else False
        """
        host_name = ffi.new("wchar_t[]", host)

        handle = ffi.new("RFID_HANDLE32 *")
        connection_info = ffi.new("CONNECTION_INFO *")
        connection_info.version = RFID_VERSIONS['RFID_API3_5_1']

        log.info("connecting to reader host: {}, port: {}.".format(host, port))
        connect_status = lib.RFID_ConnectW(
            handle, host_name, port, timeout, connection_info)

        if VerifyStatus(connect_status):
            # updating reader handle
            self.Handle = handle[0]
            return True
        else:
            log.error(
                "connect api failed. Host: {}, port: {}.".format(host, port))
            return False

    def Disconnect(self):
        """
        Disconnects reader
        :return: True if success else False
        """
        log.info("disconnecting reader.")
        disconnect_status = lib.RFID_Disconnect(self.Handle)
        return VerifyStatus(disconnect_status)

    def SetTraceLevel(self, level=0):
        """
        sets trace level
        :param level: trace level range(0, MAX)
        :return: True if success else False
        """
        log.info("setting trace level to {}".format(level))
        trace_level_status = lib.RFID_SetTraceLevel(self.Handle, level)
        return VerifyStatus(trace_level_status)

    def GetReaderCapabilities(self):
        """
        returns current reader capabilities
        :return: True if success else False
        """
        log.info("requesting capabilities.")
        capabilities = ffi.new("READER_CAPSW *")
        status = lib.RFID_GetReaderCapsW(self.Handle, capabilities)
        if VerifyStatus(status):
            self.Capabilities = ReaderCapabilities(capabilities)
            self.Action.PreFilters.max_prefilters = self.Capabilities.maxNumPreFilters
            return True
        return False
