#!/usr/bin/python3

from socket import *
import re
import socket
import sys

# Import modules for CGI handling 
import cgi, cgitb 

HOST = '127.0.0.1' # Local Socket
PORT = 50009      


# Get the POST data
postdata = sys.stdin.readline()

# Create Socket
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))

# Send the data
s.send(postdata)
response = s.recv(4096)
sys.stdout.write("Content-type: text/html\n\n");
sys.stdout.write(response);
s.close()

