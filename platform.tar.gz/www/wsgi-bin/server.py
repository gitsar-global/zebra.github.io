import sys
sys.path.insert(1, '/platform/lib')

import json
import socket
import threading
import traceback
import time
from queue import Queue

from RFID3 import *
from RFID3.support import log
from rest_constants import supported_commands, ErrorTypes
import urllib.request
from urllib.parse import urlparse
import http.client
import syslog
import ssl


__version__ = "1.0.0"

# Global variables

tags_read = Queue()
tag_event_queue = Queue()
available_tags = []
call_back_error = False

# For GetCfg RCI
binary = 'HEX'
rdrname = 'Zebra-'
sant = False
sdt = False
sphs = False
srssi = False
srz = False
tag_url = None
is_https_url = False
headers = {"Content-Type": "application/json"}
report_err_desc = False
stop_thread1 = False

sslSettings = ssl.SSLContext(ssl.PROTOCOL_TLS)
sslSettings.check_hostname = True
sslSettings.verify_mode = ssl.CERT_REQUIRED
sslSettings.load_verify_locations(cafile='/readerconfig/ssl/server.crt', capath=None, cadata=None)
sslSettings.load_cert_chain(certfile='/readerconfig/ssl/server.crt', keyfile='/readerconfig/ssl/server.key')

TagEventFields = {
    "Ant": False,
    "DT": False,
    "PC": True,
    "Phase": False,
    "Prof": True,
    "RSSI": False,
    "RZ": False,
    "Spot": True,
    "EPC": True,
    "Scheme": True
}

InventoryDataSemaphore = threading.Semaphore(0)
StartRZSemaphore = threading.Semaphore(0)

stop_reading = False
startrz = False

init = False
Capabilities = None
num_antennas = None
g_rz_params = None
gReaderHandle = None
prefilterfilters = [None for i in range(32)]

def SendResponse(response):
    """
    send response
    :param response: response
    :return: None
    """

    try:
        if report_err_desc:
            if "ErrID" in response.keys():
                if response["ErrID"] in ErrorTypes.keys():
                    response["ErrDesc"] = ErrorTypes[response["ErrID"]]
                else:
                    response["ErrDesc"] = "Unknown Error Received"
            else:
                response["ErrID"] = 1002
                response["ErrDesc"] = "Unknown Error Received"
        json_response = json.dumps(response).encode('utf-8')
        syslog.syslog(syslog.LOG_INFO, "response: {}".format(json_response))
        log.info("Response: {}".format(json_response))
        client.sendall(json_response)
        client.close()
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SendResponse: {}".format(var))
        log.error("exception: {}".format(var))


def CheckRequest(req):
    """
    check request
    :param req:
    :return: True if success else False
    """
    if 'Cmd' in req.keys():
        command = req['Cmd']
        return command in supported_commands
    else:
        return False


def verify_json_schema(received_fields, available_fields):

    return set(received_fields).issubset(set(available_fields))


def is_same(list1, list2):

    for ele in list2:
        if ele not in list1:
            return False
    return True


def GetInfoHandler(req):
    """
    Get Info command handler
    :param req: Fields
    :return: None
    """
    try:
        if (not is_same(list(req.keys()), ["Cmd", "Fields"])) or (not is_same(["Cmd", "Fields"], list(req.keys()))):
            response = {"Report": "GetInfo", "ErrID": 21}
            SendResponse(response)
            return

        params = req['Fields']

        serialNumber = Capabilities.readerID
        modelName = Capabilities.modelName
        firmWareVersion = Capabilities.firmWareVersion

        if isinstance(params, list):
            supported_fields = ["RdrModel", "RdrSN", "Version"]
            response = {"Report": "GetInfo", "ErrID": 0}
            if len(params) == 0:
                response = {"Report": "GetInfo", "ErrID": 22}
                SendResponse(response)
                return

            for param in params:
                if not isinstance(param, str):
                    response = {"Report": "GetInfo", "ErrID": 22}
                    SendResponse(response)
                    return
                elif param.lower() == "all" and len(params) > 1:
                    response = {"Report": "GetInfo", "ErrID": 22}
                    SendResponse(response)
                    return
                elif param.lower() == "all":
                    response['RdrSN'] = serialNumber
                    response['RdrModel'] = modelName
                    response['Version'] = firmWareVersion
                    SendResponse(response)
                    return
                elif param not in supported_fields:
                    response = {"Report": "GetInfo", "ErrID": 22}
                    SendResponse(response)
                    return
                elif param == "RdrSN":
                    response['RdrSN'] = serialNumber
                elif param == "RdrModel":
                    response['RdrModel'] = modelName
                elif param == "Version":
                    response['Version'] = firmWareVersion
            SendResponse(response)
            return
        else:
            response = {"Report": "GetInfo", "ErrID": 22}
            SendResponse(response)
            return

    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetInfoHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "GetInfo", "ErrID": 1002}
    SendResponse(response)


def GetGPIOHandler(req):
    """
    GPIO command handler
    :param req: fields
    :return: None
    """
    try:
        supported_fields = ["Cmd", "ReportNow", "Type"]
        received_fields = list(req.keys())

        if (not is_same(received_fields, supported_fields)) or (not is_same(supported_fields, received_fields)):
            response = {"Report": "GetGPIOs", "ErrID": 21}
            SendResponse(response)
            return

        if not isinstance(req["ReportNow"], list):
            response = {"Report": "GetGPIOs", "ErrID": 22}
            SendResponse(response)
            return

        gpio_type = req['Type']

        pins = req["ReportNow"]

        pin = []

        reader = RFIDReader()

        for i in pins:
            if not isinstance(i, int):
                response = {"Report": "GetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

            if i == 0:
                if len(pins) != 1:
                    response = {"Report": "GetGPIOs", "ErrID": 22}
                    SendResponse(response)
                    return
                if gpio_type == "IN":
                    pin = range(1, reader.Capabilities.numGPIs + 1)
                else:
                    pin = range(1, reader.Capabilities.numGPOs + 1)
            else:
                pin.append(i)

        if gpio_type == "IN":

            states = []
            for p in pin:

                if (not isinstance(p, int)) and p not in range(1, reader.Capabilities.numGPIs + 1):
                    response = {"Report": "GetGPIOs", "ErrID": 22}
                    SendResponse(response)
                    return

                state = reader.Config.GPIConfig.Get(int(p))

                if state is None:
                    response = {"Report": "GetGPIOs", "ErrID": 1001}
                    SendResponse(response)
                    return

                states.append([p, "IN", True if state.state.value == 1 else False])

            response = {"Report": "GetGPIOs", "ErrID": 0, "GPIOs": states}

        elif gpio_type == "OUT":

            states = []
            for p in pin:

                if p not in range(1, reader.Capabilities.numGPOs + 1):
                    response = {"Report": "GetGPIOs", "ErrID": 22}
                    SendResponse(response)
                    return

                state = reader.Config.GPOConfig.Get(int(p))

                if state is None:
                    response = {"Report": "GetGPIOs", "ErrID": 1001}
                    SendResponse(response)
                    return

                states.append([p, "OUT", True if state.value == 1 else False])

            response = {"Report": "GetGPIOs", "ErrID": 0, "GPIOs": states}

        else:
            response = {"Report": "GetGPIOs", "ErrID": 22}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetGPIOHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "GetGPIOs", "ErrID": 1002}
    SendResponse(response)


def SetGPIOHandler(req):
    """
    set GPIO handler
    :param req: pin number, pin state
    :return: None
    """
    try:
        supported_fields = ["Cmd", "GPIOs"]
        received_fields = list(req.keys())

        if (not is_same(received_fields, supported_fields)) or (not is_same(supported_fields, received_fields)):
            response = {"Report": "SetGPIOs", "ErrID": 21}
            SendResponse(response)
            return

        if not isinstance(req["GPIOs"], list):
            response = {"Report": "SetGPIOs", "ErrID": 22}
            SendResponse(response)
            return

        set_values = req["GPIOs"]

        reader = RFIDReader()

        response = {"Report": "SetGPIOs", "ErrID": 22}

        for set_value in set_values:

            if not isinstance(set_value, list):
                response = {"Report": "SetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

            if len(set_value) != 2:
                response = {"Report": "SetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

            _pin, _state = set_value

            if _pin not in range(1, reader.Capabilities.numGPOs + 1):
                response = {"Report": "SetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

            if not isinstance(_state, bool):
                response = {"Report": "SetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

        for set_value in set_values:

            pin = set_value[0]
            state = set_value[1]

            if not (isinstance(pin, int) and isinstance(state, bool)):
                response = {"Report": "SetGPIOs", "ErrID": 22}
                SendResponse(response)
                return

            status = reader.Config.GPOConfig.Set(pin, state)

            if status:
                response["ErrID"] = 0
            else:
                response["ErrID"] = 1001
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SetGPIOHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "SetGPIOs", "ErrID": 1002}
    SendResponse(response)


def GetRZ(aID, reader=None):
    """

    :param aID:
    :param reader:
    :return:
    """
    global g_rz_params
    response = {"Report": "GetRZ", "ErrID": 0}
    try:
        if aID == 0 and aID > num_antennas:
            response = {"Report": "GetRZ", "ErrID": 22}
            return response
        rz_params = g_rz_params[aID - 1]
        if rz_params is None:
            if reader is None:
                reader = RFIDReader()
            # To get Transmit Power
            response_ant = reader.Config.AntennaConfig.Get(aID)
            if response_ant is None:
                response = {"Report": "GetRZ", "ErrID": 1004}
                return response
            else:
                response["ReadPwr"] = response_ant.pTransmitPowerIndex
            # To get singulation control
            response_ret = reader.Config.SingulationControl.Get(aID)
            if response_ret is None:
                response = {"Report": "GetRZ", "ErrID": 1003}
                return response
            else:
                response['Q'] = response_ret.tagPopulation
                response['Session'] = response_ret.session.value
                if response_ret.stateAwareSingulationAction.perform:
                    response['Target'] = response_ret.stateAwareSingulationAction.inventoryState.value
                    response['SelectFlag'] = response_ret.stateAwareSingulationAction.slFlag.value
                else:
                    response['Target'] = "NONE"
                    response['SelectFlag'] = "NONE"
        else:
            response = rz_params
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetRZ: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "GetRZ", "ErrID": 1002}
    return response.copy()


def GetRZHandler(req):
    """
    get Singulation control
    :return: Json payload to server
    """
    try:
        supported_fields = ["Cmd", "ID"]

        if not is_same(list(req.keys()), supported_fields) or not is_same(supported_fields, list(req.keys())):
            response = {"Report": "GetRZ", "ErrID": 21}
            SendResponse(response)
            return

        if not isinstance(req['ID'], int):
            response = {"Report": "GetRZ", "ErrID": 22}
            SendResponse(response)
            return

        if 1 < req['ID'] > num_antennas:
            response = {"Report": "GetRZ", "ErrID": 22}
            SendResponse(response)
            return

        antenna_id = int(req['ID'])
        response = GetRZ(antenna_id)

        if response['ErrID'] == 0:
            target = {
                0: "A",
                1: "B",
                2: "AB",
                "NONE": "NONE"
            }
            response["Target"] = target[response["Target"]]

            sl_flag = {
                0: "SL",
                1: "~SL",
                2: "ALL",
                "NONE": "NONE"
            }
            response['SelectFlag'] = sl_flag[response['SelectFlag']]

    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetRZHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "GetRZ", "ErrID": 1002}
    SendResponse(response)


def SetRZ(req, antenna_id, reader=None):
    """

    :param antenna_id:
    :param req:
    :param reader:
    :return:
    """
    cmd_status = True

    try:
        if antenna_id == 0:
            ant_id = 1
        else:
            ant_id = antenna_id

        if reader is None:
            reader = RFIDReader()

        # singulation control
        curr_singulation = reader.Config.SingulationControl.Get(ant_id)
        if curr_singulation is None:
            cmd_status = False
            log.error("SET RZ: Failed")
        else:
            if 'Session' in req.keys():
                session = int(req['Session'])
                curr_singulation.session = session
                log.info("SET RZ: session: {}".format(session))

            if 'Q' in req.keys():
                q = int(req['Q'])
                curr_singulation.tagPopulation = q
                log.info("SET RZ: Q: {}".format(q))

            if 'Target' in req.keys():
                if req["Target"] == "NONE":
                    curr_singulation.stateAwareSingulationAction.perform = 0
                else:
                    target = int(req['Target'])
                    curr_singulation.stateAwareSingulationAction.perform = 1
                    curr_singulation.stateAwareSingulationAction.inventoryState = target
                    log.info("SET RZ: target: {}".format(target))

            if 'SelectFlag' in req.keys():
                if req["SelectFlag"] == "NONE":
                    curr_singulation.stateAwareSingulationAction.perform = 0
                else:
                    select_flag = int(req['SelectFlag'])
                    curr_singulation.stateAwareSingulationAction.perform = 1
                    curr_singulation.stateAwareSingulationAction.slFlag = select_flag
                    log.info("SET RZ: SelectFlag: {}".format(select_flag))

            if not reader.Config.SingulationControl.Set(curr_singulation, antenna_id):
                cmd_status = False
                log.error("SET RZ: Failed")

        if 'ReadPwr' in req.keys():
            # Antenna Config
            curr_ant_config = reader.Config.AntennaConfig.Get(ant_id)
            if curr_ant_config is None:
                cmd_status = False
                log.error("SET RZ: Failed")
            else:
                reader_power = int(req['ReadPwr'])
                curr_ant_config.pTransmitPowerIndex = reader_power
                if not reader.Config.AntennaConfig.Set(curr_ant_config, antenna_id):
                    cmd_status = False
                    log.error("SET RZ: Failed")
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SetRZ: {}".format(var))
        log.error("exception: {}".format(var))
        cmd_status = False

    return cmd_status


def SetRZHandler(req):
    """
    SetRZ command handler
    :return: Json payload to server
    """
    try:
        supported_fields = ["Cmd", "ID", "Session", "Q", "Target", "SelectFlag", "ReadPwr"]

        if 'ID' in req.keys() and not isinstance(req['ID'], int):
            response = {"Report": "SetRZ", "ErrID": 22}
            SendResponse(response)
            return

        if not verify_json_schema(list(req.keys()), supported_fields):
            response = {"Report": "SetRZ", "ErrID": 22}
            SendResponse(response)
            return

        if "ID" in req.keys() and not isinstance(req['ID'], int):
            response = {"Report": "SetRZ", "ErrID": 22}
            SendResponse(response)
            return

        antenna_id = int(req['ID'])

        if antenna_id > num_antennas:
            response = {"Report": "SetRZ", "ErrID": 22}
            SendResponse(response)
            return
        else:
            reader = RFIDReader()
            ant_id = 1 if antenna_id == 0 else antenna_id
            curr_rz_params = GetRZ(aID=ant_id, reader=reader)

            if curr_rz_params['ErrID'] != 0:
                response = {"Report": "SetRZ", "ErrID": curr_rz_params['ErrID']}
                SendResponse(response)
                return

            if 'Session' in req.keys():
                if not isinstance(req['Session'], int):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return
                curr_rz_params['Session'] = int(req['Session'])

            if 'Q' in req.keys():
                if not isinstance(req['Q'], int):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return
                curr_rz_params['Q'] = int(req['Q'])

            if 'Target' in req.keys() and 'SelectFlag' in req.keys():
                if (req['Target'] == "NONE" and req['SelectFlag'] != "NONE") or (req['Target'] != "NONE" and req['SelectFlag'] == "NONE"):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return

            if 'Target' in req.keys():
                if not isinstance(req['Target'], str):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return

                if req['Target'] not in ["A", "B", "AB", "NONE"]:
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return

                target = {
                    "A": 0,
                    "B": 1,
                    "AB": 2,
                    "NONE": "NONE"
                }

                curr_rz_params['Target'] = target[req['Target']]

            if 'SelectFlag' in req.keys():
                if not isinstance(req['SelectFlag'], str):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return

                if req['SelectFlag'] not in ["SL", "~SL", "ALL", "NONE"]:
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return

                sl_flag = {
                    "SL": 0,
                    "~SL": 1,
                    "ALL": 2,
                    "NONE": "NONE"
                }
                curr_rz_params['SelectFlag'] = sl_flag[req['SelectFlag']]

            if 'ReadPwr' in req.keys():
                if not isinstance(req['Q'], (int, float)):
                    response = {"Report": "SetRZ", "ErrID": 22}
                    SendResponse(response)
                    return
                curr_rz_params['ReadPwr'] = req['ReadPwr']

            cmd_status = SetRZ(curr_rz_params, antenna_id, reader)

            if cmd_status:
                if antenna_id == 0:
                    for i in range(0, num_antennas):
                        g_rz_params[i] = curr_rz_params.copy()
                else:
                    g_rz_params[antenna_id - 1] = curr_rz_params.copy()

                response = {"Report": "SetRZ", "ErrID": 0}
            else:
                response = {"Report": "SetRZ", "ErrID": 1004}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SetRZHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "SetRZ", "ErrID": 1002}

    SendResponse(response)


def GetCfgHandler(req):
    """
    Return current configuration
    :return:
    """
    try:
        if not is_same(list(req.keys()), ["Cmd", "Fields"]) and not is_same(["Cmd", "Fields"], list(req.keys())):
            response = {"Report": "GetCfg", "ErrID": 21}
            SendResponse(response)
            return

        params = req['Fields']

        if isinstance(params, list):
            supported_fields = ["Binary", "RdrName", "SpotAnt", "SpotDT", "SpotPhase", "SpotRSSI", "SpotRZ", "_PostTagEventsUrl", "ReportErrDesc"]
            response = {"Report": "GetCfg", "ErrID": 0}
            for param in params:
                if not isinstance(param, str):
                    response = {"Report": "GetCfg", "ErrID": 22}
                    SendResponse(response)
                    return
                if param.lower() == "all" and len(params) > 1:
                    response = {"Report": "GetCfg", "ErrID": 22}
                    SendResponse(response)
                    return
                elif param.lower() == "all":
                    response["Binary"] = binary
                    response["RdrName"] = rdrname
                    response["SpotAnt"] = sant
                    response["SpotDT"] = sdt
                    response["SpotPhase"] = sphs
                    response["SpotRSSI"] = srssi
                    response["SpotRZ"] = srz
                    response["_PostTagEventsUrl"] = tag_url if tag_url is not None else ' '
                    response["ReportErrDesc"] = report_err_desc
                elif param not in supported_fields:
                    response = {"Report": "GetCfg", "ErrID": 22}
                    SendResponse(response)
                    return
                elif param == "Binary":
                    response["Binary"] = binary
                elif param == "RdrName":
                    response["RdrName"] = rdrname
                elif param == "SpotAnt":
                    response["SpotAnt"] = sant
                elif param == "SpotDT":
                    response["SpotDT"] = sdt
                elif param == "SpotPhase":
                    response["SpotPhase"] = sphs
                elif param == "SpotRSSI":
                    response["SpotRSSI"] = srssi
                elif param == "SpotRZ":
                    response["SpotRZ"] = srz
                elif param == "_PostTagEventsUrl":
                    response["_PostTagEventsUrl"] = tag_url if tag_url is not None else ' '
                elif param == "ReportErrDesc":
                    response["ReportErrDesc"] = report_err_desc

            SendResponse(response)
            return
        else:
            response = {"Report": "GetCfg", "ErrID": 22}
            SendResponse(response)
            return

    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetCfgHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "GetCfg", "ErrID": 1002}

    SendResponse(response)


def SetCfgHandler(req):
    """
    :return:
    """
    global sant, sdt, sphs, srssi, srz, binary, rdrname, tag_url, report_err_desc, is_https_url, sslSettings
    
    verify_mode = True
    check_hostname = True

    try:
        supported_fields = ["Cmd", "Binary", "RdrName", "SpotAnt", "SpotDT", "SpotPhase", "SpotRSSI", "SpotRZ", "_PostTagEventsUrl", "_VerifyPeer", "_VerifyHost", "ReportErrDesc"]

        if not verify_json_schema(list(req.keys()), supported_fields):
            response = {"Report": "GetCfg", "ErrID": 21}
            SendResponse(response)
            return

        if '_PostTagEventsUrl' in req.keys():
            if not isinstance(req['_PostTagEventsUrl'], str):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            _tag_url = req['_PostTagEventsUrl']
            # validating tag url
            parsed_url = urlparse(_tag_url)            
            if parsed_url.scheme == 'https':
                is_https_url = True
            elif parsed_url.scheme == 'http':
                is_https_url = False
            else:
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            tag_url = _tag_url

        if '_VerifyPeer' in req.keys():
            if not isinstance(req['_VerifyPeer'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            
            verify_mode = req['_VerifyPeer']
            
        if '_VerifyHost' in req.keys():
            if not isinstance(req['_VerifyHost'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            
            check_hostname = req['_VerifyHost']
        
        if verify_mode:
            sslSettings.verify_mode = ssl.CERT_REQUIRED
            if check_hostname:
                sslSettings.check_hostname = True
            else:
                sslSettings.check_hostname = False
        else:
            sslSettings.check_hostname = False
            sslSettings.verify_mode = ssl.CERT_NONE

        if "ReportErrDesc" in req.keys():
            if not isinstance(req['ReportErrDesc'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            report_err_desc = req['ReportErrDesc']

        if 'Binary' in req.keys():
            if not isinstance(req['Binary'], str):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            if req['Binary'] != "HEX":
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            binary = req['Binary']

        if 'RdrName' in req.keys():
            if not isinstance(req['RdrName'], str):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            rdrname = req['RdrName']

        if 'SpotAnt' in req.keys():
            if not isinstance(req['SpotAnt'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            sant = req['SpotAnt']
            TagEventFields["Ant"] = sant

        if 'SpotDT' in req.keys():
            if not isinstance(req['SpotDT'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            sdt = req['SpotDT']
            TagEventFields["DT"] = sdt

        if 'SpotPhase' in req.keys():
            if not isinstance(req['SpotPhase'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            sphs = req['SpotPhase']
            TagEventFields["Phase"] = sphs

        if 'SpotRSSI' in req.keys():
            if not isinstance(req['SpotRSSI'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            srssi = req['SpotRSSI']
            TagEventFields["RSSI"] = srssi

        if 'SpotRZ' in req.keys():
            if not isinstance(req['SpotRZ'], bool):
                response = {"Report": "SetCfg", "ErrID": 22}
                SendResponse(response)
                return
            srz = req['SpotRZ']
            TagEventFields["RZ"] = srz

        response = {"Report": "SetCfg", "ErrID": 0}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SetCfgHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "SetCfg", "ErrID": 1002}
    SendResponse(response)


def InitInventory():
    """

    :return:
    """
    # Setting RZ params
    global g_rz_params, gReaderHandle, prefilterfilters

    log.info("setting read zone params")
    print("Global RZ params: {}\n".format(g_rz_params))
    for antenna_id, param in enumerate(g_rz_params):
        print("Setting: {} for antenna: {}\n".format(param, antenna_id))
        if param is not None:
            SetRZ(param, antenna_id+1, gReaderHandle)

    print("Global Filters: {}\n".format(prefilterfilters))
    for prefilterfilter in prefilterfilters:
        if prefilterfilter is not None:
            prefilter, read_zones, _ = prefilterfilter
            for read_zone in read_zones:
                gReaderHandle.Action.PreFilters.Add(filter=prefilter, antenna=read_zone)


def FormTagBuffer(pTagData):
    """

    :param pTagData:
    :return:
    """
    response = {"Report": "TagEvent", "ErrID": 0}

    if report_err_desc:
        response["ReportErrDesc"] = ErrorTypes[0]

    if TagEventFields["Ant"]:
        response["Ant"] = int(pTagData.antennaID)

    if TagEventFields["DT"]:
        response["DT"] = pTagData.firstSeenTimeStamp

    if TagEventFields["PC"]:
        response["PC"] = pTagData.PC

    if TagEventFields["Phase"]:
        response["Phase"] = pTagData.phaseInfo

    if TagEventFields["Prof"]:
        response["Prof"] = 1

    if TagEventFields["RSSI"]:
        response["RSSI"] = pTagData.peakRSSI

    if TagEventFields["RZ"]:
        response["RZ"] = 1

    if TagEventFields["Spot"]:
        response["Spot"] = "FirstSeen"

    if TagEventFields["EPC"]:
        response["EPC"] = pTagData.EPC

    if TagEventFields["Scheme"]:
        response["Scheme"] = pTagData.TagType

    return response


def ReadTags():
    """
    read tags thread
    :return:
    """
    global stop_reading, gReaderHandle
    try:
        tags = []
        while True:
            gReaderHandle.Action.GetReadTags()
            if gReaderHandle.Action.processed_tags:
                tags.extend(gReaderHandle.Action.processed_tags)
            if stop_reading:
                stop_reading = False
                break
        if tags:
            tags = list(map(lambda x: FormTagBuffer(x), tags))

        response = {"Report": "_GetTags", "Tags": tags, "ErrID": 0}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in ReadTags: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"error": "Command Failed"}
    SendResponse(response)
    log.info("read tags thread stopped")


def StartReadTag():
    """
    GetTags cmd handler
    :return: None
    """
    startRZThreadHandle = threading.Thread(target=ReadTags)
    startRZThreadHandle.start()


def GetTagsCallBack(event):
    global stop_reading, tags_read
    if event == 4:
        log.info("inventory start")
        syslog.syslog(syslog.LOG_INFO, "INVENTORY START EVENT")
    if event == 1:
        print("Tag Data received")
        try:
            gReaderHandle.Action.GetReadTags()
            if gReaderHandle.Action.processed_tags:
                for tag_data in gReaderHandle.Action.processed_tags:
                    tags_read.put(tag_data)
        except:
            pass
    if event == 5:
        log.info("inventory stop")
        syslog.syslog(syslog.LOG_INFO, "INVENTORY STOP EVENT")
        InventoryDataSemaphore.release()
        stop_reading = True


def StartRZCallBack(event):
    global stop_reading, tags_read, tag_event_queue
    if event == 4:
        log.info("inventory start")
        syslog.syslog(syslog.LOG_INFO, "INVENTORY START EVENT")
    if event == 1:
        tag_event_queue.put(1)
    if event == 5:
        log.info("inventory stop")
        tag_event_queue.put(0)
        syslog.syslog(syslog.LOG_INFO, "INVENTORY STOP EVENT")
        StartRZSemaphore.release()
        stop_reading = True


def TagEventHandlerThread():

    global tag_event_queue, gReaderHandle, stop_reading

    while True:

        try:

            tag_event = tag_event_queue.get()

            if tag_event == 0:
                stop_reading = True
                print("Inventory stopped breaking thread")
                break

            # Reading tags
            if isinstance(gReaderHandle, RFIDReader):
                gReaderHandle.Action.GetReadTags()
                if gReaderHandle.Action.processed_tags:
                    tag_count = 0
                    tags = []
                    for tag in gReaderHandle.Action.processed_tags:
                        tags.append(FormTagBuffer(tag))
                        tag_count += 1
                        if tag_count >= 100:
                            send_to_url(tags)
                            tags = []
                            tag_count = 0

                    if len(tags) > 0:
                        send_to_url(tags)
                        tags = []
                        tag_count = 0

                    # tags = map(lambda x: FormTagBuffer(
                    #     x), gReaderHandle.Action.processed_tags)
                    # send_to_url(list(tags))
        except:
            var = traceback.format_exc()
            syslog.syslog(syslog.LOG_INFO, "Exception in TagEventHandlerThread: {}".format(var))
            log.error("exception: {}".format(var))


def TagEventHandlerThread1():
    
    global gReaderHandle

    while not stop_thread1:
        try:
            if isinstance(gReaderHandle, RFIDReader):
                gReaderHandle.Action.GetReadTags()
                if gReaderHandle.Action.processed_tags:
                    tag_count = 0
                    tags = []
                    for tag in gReaderHandle.Action.processed_tags:
                        tags.append(FormTagBuffer(tag))
                        tag_count += 1
                        if tag_count >= 100:
                            send_to_url(tags)
                            tags = []
                            tag_count = 0
                    if len(tags) > 0:
                        send_to_url(tags)
                        tags = []
                        tag_count = 0
                else:
                    time.sleep(0.1)
            else:
               time.sleep(0.1) 
                
        except:
            var = traceback.format_exc()
            syslog.syslog(syslog.LOG_INFO, "Exception in TagEventHandlerThread: {}".format(var))
            log.error("exception: {}".format(var))
            time.sleep(0.1)

def GetTagsHandler(request_params):
    """
    GetTags cmd handler
    :param request_params: request params
    :return:
    """
    global stop_reading, gReaderHandle, tags_read

    try:
        # read_zones = "RZs"
        stop_condition = "_StopCondition"
        stop_value = "_StopValue"

        supported_fields = ["Cmd", stop_condition, stop_value]

        if not is_same(list(request_params.keys()), supported_fields) or not is_same(supported_fields, list(request_params.keys())):
            response = {"Report": "_GetTags", "ErrID": 21}
            SendResponse(response)
            return

        # rzs = request_params.get(read_zones, None)
        stpc = request_params.get(stop_condition, None)
        stpv = request_params.get(stop_value, None)

        # if not isinstance(rzs, list):
        #     response = {"Report": "_GetTags", "ErrID": 22}
        #     SendResponse(response)
        #     return

        if not isinstance(stpc, int):
            response = {"Report": "_GetTags", "ErrID": 22}
            SendResponse(response)
            return

        if not isinstance(stpv, int):
            response = {"Report": "_GetTags", "ErrID": 22}
            SendResponse(response)
            return

        if stpc not in [1, 2, 3]:
            response = {"Report": "_GetTags", "ErrID": 22}
            SendResponse(response)
            return

        stop_val = int(stpc)

        # for read_zone in rzs:
        #     if not isinstance(read_zone, int):
        #         response = {"Report": "_GetTags", "ErrID": 22}
        #         SendResponse(response)
        #         return
        #     if 0 > read_zone > num_antennas:
        #         response = {"Report": "_GetTags", "ErrID": 22}
        #         SendResponse(response)
        #         return
        #     if read_zone == 0 and len(read_zones) > 1:
        #         response = {"Report": "_GetTags", "ErrID": 22}
        #         SendResponse(response)
        #         return
        #     if read_zone == 0 and len(read_zones) == 1:
        #         read_zones = list(range(1, num_antennas+1))
        #         break

        # building trigger
        trigger = None
        if stop_val == 1:
            trigger = TriggerInfo()
            trigger.startTrigger.Immediate()
            trigger.stopTrigger.NAttemptWithTimeout(int(stpv), 5000)
        elif stop_val == 2:
            if stpv > 6 * 1000:
                response = {"Report": "_GetTags", "ErrID": 22}
                SendResponse(response)
                return
            trigger = TriggerInfo()
            trigger.startTrigger.Immediate()
            t_ms = int(stpv)
            trigger.stopTrigger.Duration(t_ms)
        elif stop_val == 3:
            if stpv > 6:
                response = {"Report": "_GetTags", "ErrID": 22}
                SendResponse(response)
                return
            trigger = TriggerInfo()
            trigger.startTrigger.Immediate()
            t_s = int(stpv) * 1000
            trigger.stopTrigger.Duration(t_s)

        gReaderHandle = RFIDReader()
        InitInventory()
        gReaderHandle.Config.DiscardTagsOnInventoryStop = False

        # registering callback
        gReaderHandle.Event.inventory_stop_event = True
        gReaderHandle.Event.inventory_start_event = True
        gReaderHandle.Event.tag_data_event = True
        gReaderHandle.Event.RegisterCallback(cb=GetTagsCallBack)

        # # setting antenna rf config
        # antrf_config = gReaderHandle.Config.AntennaRFConfig.Get(1)
        # for read_zone in rzs:
        #     antrf_config.antennaStopTrigger.stopTriggerType = int(stpc)
        #     antrf_config.antennaStopTrigger.stopTriggerValue = int(stpv)
        #     gReaderHandle.Config.AntennaRFConfig.Set(antrf_config, read_zone)

        # perform inventory
        stop_reading = False
        gReaderHandle.Action.Inventory.Perform(None, None, trigger)
        # StartReadTag()
        InventoryDataSemaphore.acquire()

        tags = []

        while not tags_read.empty():
            tags.append(tags_read.get())

        if tags:
            tags = list(map(lambda x: FormTagBuffer(x), tags))

        response = {"Report": "_GetTags", "Tags": tags, "ErrID": 0}

        gReaderHandle.DeInitialize()
        gReaderHandle = None
        SendResponse(response)
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetTagsHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "_GetTags", "ErrID": 1002}

        while not tags_read.empty():
            tags_read.get()

        SendResponse(response)


def send_to_url(local_tags):
    """
    Post tags to register url
    :param local_tags: list of tags
    :return: None
    """
    global tag_url, is_https_url, sslSettings
    
    data = json.dumps({"Tags": local_tags})
    data = str(data)
    data = data.encode('utf-8')
    request = urllib.request.Request(url=tag_url, data=data, headers=headers)

    if is_https_url:
        with urllib.request.urlopen(request, context=sslSettings):
            pass
    else:
        with urllib.request.urlopen(request):
            pass

def PostTags():
    """
    post tags to registered url
    :return: None
    """
    global stop_reading, gReaderHandle, tags_read

    print("Starting Thread\n")
    try:
        while True:
            if stop_reading:
                break

            _tags = []
            start_time = time.time()

            print("Tags_read: {}".format(tags_read.qsize()))

            while not tags_read.empty():
                _tags.append(tags_read.get())

                if time.time() - start_time > 2:
                    break

            if _tags:
                send_to_url(list(map(lambda x: FormTagBuffer(x), _tags)))
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in PostTags: {}".format(var))
        log.error("exception: {}".format(var))
    log.info("post tag thread stopped")


def StartRZThread():
    """
    start rz thread
    :return:
    """
    global stop_thread1
    stop_thread1 = False
    startRZThreadHandle = threading.Thread(target=TagEventHandlerThread1)
    startRZThreadHandle.start()


def StartRZHandler(req):
    """
    Start Inventory on background
    :return: None
    """
    global stop_reading, gReaderHandle, startrz
    try:
        if not is_same(list(req.keys()), ["Cmd"]):
            response = {"Report": "StartRZ", "ErrID": 21}
            SendResponse(response)
            return

        if not tag_url:
            response = {"Report": "StartRZ", "ErrID": 1005}
        elif not startrz:
            stop_reading = False
            gReaderHandle = RFIDReader()

            # registering callback
            # gReaderHandle.Event.inventory_stop_event = True
            # gReaderHandle.Event.inventory_start_event = True
            # gReaderHandle.Event.tag_data_event = True
            # gReaderHandle.Event.RegisterCallback(cb=StartRZCallBack)

            InitInventory()
            gReaderHandle.Config.DiscardTagsOnInventoryStop = False
            inv_status = gReaderHandle.Action.Inventory.Perform()
            if not inv_status:
                response = {"Report": "StartRZ", "ErrID": 1009}
            else:
                response = {"Report": "StartRZ", "ErrID": 0}
                startrz = True
                StartRZThread()
        else:
            response = {"Report": "StartRZ", "ErrID": 1008}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in StartRZHandler: {}".format(var))
        log.error("exception: {}".format(var))
        if isinstance(gReaderHandle, RFIDReader):
            try:
                gReaderHandle.Action.Inventory.Stop()
            except:
                pass
            gReaderHandle.DeInitialize()
            gReaderHandle = None
        response = {"Report": "StartRZ", "ErrID": 1002}

    SendResponse(response)


def StopRZHandler(req):
    """
    Stop Inventory
    :return:
    """
    global stop_reading, gReaderHandle, startrz, stop_thread1
    startrz = False
    try:
        if not is_same(list(req.keys()), ["Cmd"]):
            response = {"Report": "StopRZ", "ErrID": 21}
            SendResponse(response)
            return

        if isinstance(gReaderHandle, RFIDReader):

            gReaderHandle.Action.Inventory.Stop()
            
            stop_thread1 = True

            # StartRZSemaphore.acquire()

            gReaderHandle.DeInitialize()
            gReaderHandle = None
            response = {"Report": "StopRZ", "ErrID": 0}
        else:
            response = {"Report": "StopRZ", "ErrID": 1006}
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in StopRZHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "StopRZ", "ErrID": 1002}
        if isinstance(gReaderHandle, RFIDReader):
            try:
                gReaderHandle.Action.Inventory.Stop()
            except:
                pass
            gReaderHandle.DeInitialize()
            gReaderHandle = None

    if not stop_reading:
        tag_event_queue.put(0)
        time.sleep(3)

    SendResponse(response)


def SetProfileHandler(req):

    try:
        supported_fields = ["Cmd", "ID", "ReadZone", "MBMask"]

        if not is_same(list(req.keys()), supported_fields) or not is_same(supported_fields, list(req.keys())):
            response = {"Report": "SetProf", "ErrID": 21}
            SendResponse(response)
            return

        if (not isinstance(req["ID"], int)) or (not isinstance(req["ReadZone"], list)) or (not isinstance(req["MBMask"], list)):
            response = {"Report": "SetProf", "ErrID": 22}
            SendResponse(response)
            return

        if req["ID"] not in range(1, 33):
            response = {"Report": "SetProf", "ErrID": 32}
            SendResponse(response)
            return

        # if req["_Action"] not in [1, 2]:
        #     response = {"Report": "SetProf", "ErrID": 22}
        #     SendResponse(response)
        #     return
        #
        # if req["_Target"] not in [0, 1, 2, 3, 4]:
        #     response = {"Report": "SetProf", "ErrID": 22}
        #     SendResponse(response)
        #     return
        #
        # if req["_ActionParam"] not in range(8):
        #     response = {"Report": "SetProf", "ErrID": 22}
        #     SendResponse(response)
        #     return

        for read_zone in req["ReadZone"]:

            if not isinstance(read_zone, int):
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if read_zone > num_antennas or read_zone < 0:
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if read_zone == 0 and len(req["ReadZone"]) > 1:
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if read_zone == 0:
                break

        mask = req["MBMask"]

        if len(mask) == 0:
            prefilterfilters[req["ID"] - 1] = None
            response = {"Report": "SetProf", "ErrID": 0}
            SendResponse(response)
        else:
            pre_filter = Filter()

            if mask[0] not in [1, 2, 3]:
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            pre_filter.memoryBank = mask[0]

            if len(mask) != 5:
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if not isinstance(mask[2], int):
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if mask[3] != ":FFFF":
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            if mask[2] % 8:
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            pre_filter.tagPatternBitCount = mask[2]

            if not isinstance(mask[4], str):
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            pre_filter.pTagPattern = mask[4]

            if not isinstance(mask[1], int):
                response = {"Report": "SetProf", "ErrID": 22}
                SendResponse(response)
                return

            pre_filter.bitOffset = mask[1]

            pre_filter.filterAction = 1
            pre_filter.filterActionParams.target = 0
            pre_filter.filterActionParams.stateAwareAction = 0

            # pre_filter.filterAction = req["_Action"]
            # pre_filter.filterActionParams.target = req["_Target"]
            # pre_filter.filterActionParams.stateAwareAction = req["_ActionParam"]

            reader = RFIDReader()

            _antennas = []
            for antenna in req["ReadZone"]:
                status = reader.Action.PreFilters.Add(pre_filter, antenna=antenna)
                if not status:
                    response = {"Report": "SetProf", "ErrID": 1007}
                    SendResponse(response)
                    return
                else:
                    _antennas.append(antenna)

            prefilterfilters[req["ID"]-1] = (pre_filter, _antennas.copy(), req.copy())
            response = {"Report": "SetProf", "ErrID": 0}
            SendResponse(response)
    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in SetProfileHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "SetProf", "ErrID": 1002}
        SendResponse(response)


def GetProfHandler(req):
    try:
        supported_fields = ["Cmd", "ID"]

        if not is_same(req.keys(), supported_fields):
            response = {"Report": "GetProf", "ErrID": 21}
            SendResponse(response)
            return

        if not isinstance(req["ID"], int):
            response = {"Report": "GetProf", "ErrID": 22}
            SendResponse(response)
            return

        if req["ID"] not in range(1, 33):
            response = {"Report": "GetProf", "ErrID": 22}
            SendResponse(response)
            return

        if prefilterfilters[req["ID"] - 1] is None:
            response = {"Report": "GetProf", "ErrID": 31}
            SendResponse(response)
            return

        _, _, filter = prefilterfilters[req["ID"] - 1]

        response = {"Report": "GetProf", "ErrID": 0, "MBMask": filter["MBMask"], "ReadZone": filter["ReadZone"]}
        SendResponse(response)

    except:
        var = traceback.format_exc()
        syslog.syslog(syslog.LOG_INFO, "Exception in GetProfHandler: {}".format(var))
        log.error("exception: {}".format(var))
        response = {"Report": "SetProf", "ErrID": 1002}
        SendResponse(response)


def InitServer():
    """
    initialize server
    :return: None
    """
    global Capabilities, num_antennas, g_rz_params, init, rdrname
    log.info("initializing rest server")
    Capabilities = RFIDReader().Capabilities
    num_antennas = Capabilities.numAntennas
    g_rz_params = [None for i in range(0, num_antennas)]
    log.info("max filters: {}".format(Capabilities.maxNumPreFilters))

    try:
        reader_name = Capabilities.serialNumber
        reader_name = reader_name.replace(':', '')
        rdrname += reader_name[-6:]
    except:
        rdrname += "000000"

    init = True


def CommandHandler(req):
    """
    command handler
    :param req:
    :return:
    """
    command = req['Cmd']

    syslog.syslog(syslog.LOG_INFO, "request received: {}".format(req))

    if not init:
        try:
            InitServer()
        except:
            var = traceback.format_exc()
            syslog.syslog(syslog.LOG_INFO, "Exception in InitServer: {}".format(var))
            log.error("exception: {}".format(var))
            response = {"Report": "Unknown", "ErrID": 1002}
            SendResponse(response)
            return

    if command == "GetInfo":
        GetInfoHandler(req)
    elif command == "GetGPIOs":
        GetGPIOHandler(req)
    elif command == "SetGPIOs":
        SetGPIOHandler(req)
    elif command == "GetRZ":
        GetRZHandler(req)
    elif command == "SetRZ":
        SetRZHandler(req)
    elif command == "GetCfg":
        GetCfgHandler(req)
    elif command == "SetCfg":
        SetCfgHandler(req)
    elif command == "_GetTags":
        GetTagsHandler(req)
    elif command == "StartRZ":
        StartRZHandler(req)
    elif command == "StopRZ":
        StopRZHandler(req)
    elif command == "SetProf":
        SetProfileHandler(req)
    elif command == "GetProf":
        GetProfHandler(req)


if __name__ == "__main__":

    # Socket creation
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    port = 50010
    s.bind(('127.0.0.1', port))
    s.listen(5)

    while True:

        client, address = s.accept()
        request = client.recv(1024)
        log.info("Request: {}".format(request))

        try:
            json_request = json.loads(request.decode('utf-8'))
        except:
            error_response = {"Report": "Unknown", "error": 1}
            SendResponse(error_response)
            continue

        if not CheckRequest(json_request):
            error_response = {"Report": "Unknown", "error": 20}
            SendResponse(error_response)
            continue

        print("******************Processing Command******************")
        CommandHandler(json_request)
        print("************************Done**************************")
