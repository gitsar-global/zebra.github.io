from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus
from RFID3.trigger import TriggerInfo


# noinspection PyMethodMayBeStatic
class Inventory:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Perform(self, postfilter=None, antenna_info=None, trigger_info=None):
        """
        start inventory
        :param postfilter: Postfilter info
        :param antenna_info: AntennaInfo Struct
        :param trigger_info: TriggerInfo Struct
        :return: True if success else False
        """
        if antenna_info is None:
            antenna_info = ffi.NULL

        if trigger_info is None:
            trigger_info = ffi.NULL
        elif isinstance(trigger_info, TriggerInfo):
            trigger_info = trigger_info.struct

        if postfilter is None:
            postfilter = ffi.NULL

        log.info("starting inventory")
        rfid_status = lib.RFID_PerformInventory(
            self.reader_handle, postfilter, antenna_info, trigger_info, ffi.NULL)
        if not VerifyStatus(rfid_status):
            log.error("Inventory operation Failed")
            return False
        else:
            log.info("Inventory started")
            return True

    def Stop(self):
        """
        stop inventory
        :return: True if success else False
        """
        log.info("Stopping Inventory")
        rfid_status = lib.RFID_StopInventory(self.reader_handle)
        return VerifyStatus(rfid_status)
