#!/bin/bash

INTRFC_NUM_FILE=/var/volatile/intrf
BNEP_IP_FILE=/readerconfig/bnepipconf
export PATH=$PATH:/usr/local/avahi/sbin:/usr/local/bluetooth/bin:/usr/local/bluetooth/sbin
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/avahi/lib:/usr/local/bluetooth/lib
NAME=pand_action.sh
PIDFILE=/var/volatile/bnep_dhcpd.pid
function valid_ip()
{
    local  ip=$1
    local  stat=1

    if [[ $ip =~ ^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$ ]]; then
        OIFS=$IFS
        IFS='.'
        ip=($ip)
        IFS=$OIFS
        [[ ${ip[0]} -le 255 && ${ip[1]} -le 255 \
            && ${ip[2]} -le 255 && ${ip[3]} -le 255 ]]
        stat=$?
    fi
    return $stat
}

function start_bt_if()
{
	#kill the second connection
	NEW_CONN=$(pand -l | grep bnep1 |cut -d " " -f 2)

	if [ "$NEW_CONN" != "" ];then
		pand --kill $NEW_CONN &> /dev/null
		return 1;
	fi

	if [ -e $INTRFC_NUM_FILE ];then
		INTRFC_NUM=$(cat $INTRFC_NUM_FILE)
		INTRFC_NUM_NEXT=$[$INTRFC_NUM+1]
	else
		INTRFC_NUM=0
		INTRFC_NUM_NEXT=1
	fi
	START_IP_OCTET3_HEX=$(bt-adapter -l | grep -v Available | cut -d : -f 5)
	START_IP_OCTET4_HEX=$(bt-adapter -l | grep -v Available | cut -d : -f 6 | cut -b 1-2)
	START_IP_OCTET3=$(printf '%d' 0x$START_IP_OCTET3_HEX)
	START_IP_OCTET4=$(printf '%d' 0x$START_IP_OCTET4_HEX)

	if [ "x$START_IP_OCTET3" == "x" ];then
		return 1;	
	fi

	echo "startip octect3= $START_IP_OCTET3"
	echo "start ip octet4= $START_IP_OCTET4"
	if [ "x$START_IP_OCTET4" == "x" ];then
		return 1;
	fi
	
	#CONSTANT_OCTETS=$(cat $BNEP_IP_FILE)
	CONSTANT_OCTETS=192.168

	START_IP=$CONSTANT_OCTETS.$START_IP_OCTET3.$START_IP_OCTET4
	valid_ip $START_IP 
	if [ ! $?  ];then
		echo "not valid ip"
		return 1;
	fi 
	
	BNEP_INTR="bnep$INTRFC_NUM"
	echo "using $START_IP for autoipd on interface $BNEP_INTR"
	ifconfig $BNEP_INTR up
	RET=$?
	if [ $RET != 0 ];then
		return 1;
	fi

	#avahi-autoipd --force-bind $BNEP_INTR -D --start=$START_IP --script=/usr/local/avahi/etc/avahi/avahi-autoipd.action
	ip addr add "$START_IP"/16 brd $CONSTANT_OCTETS.255.255 label "$BNEP_INTR" scope link dev "$BNEP_INTR"
        ip route add default dev "$BNEP_INTR" scope link ||:

	RET=$?
	if [ $RET != 0 ];then
		return 1;
	fi

	sleep 5;

	#start-stop-daemon --stop --oknodo --pidfile $PIDFILE
	start-stop-daemon --start --oknodo -m --pidfile $PIDFILE --background --exec udhcpd -- /etc/udhcpdbnep.conf -f
	#udhcpd /etc/udhcpdbnep.conf

	return 0;
}


function stop_bt_if()
{
	rm -rf $INTRFC_NUM_FILE
	start-stop-daemon --stop --oknodo --pidfile $PIDFILE
}

case "$1" in
  up)
    start_bt_if
    RET=$?
    if [ $RET == 0 ];then
    	rm -rf $INTRFC_NUM_FILE
	echo "$INTRFC_NUM_NEXT" > $INTRFC_NUM_FILE
    fi
  ;;
  down)
    stop_bt_if
  ;;
  restart)
    stop_bt
    sleep 1
    start_bt
  ;;
  *)
    echo "Usage: /etc/init.d/$NAME {up|down|restart}" >&2
  ;;
esac

