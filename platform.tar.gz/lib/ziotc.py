import asyncio

import os
import struct
import signal

import pyziotc
import time

ZIOTC_MSG_TYPE_TAG_INFO_JSON      = pyziotc.MSG_IN_JSON
ZIOTC_MSG_TYPE_TAG_INFO_BIN       = pyziotc.MSG_IN_BIN
ZIOTC_MSG_TYPE_TAG_INFO_BEARING   = pyziotc.MSG_IN_BEARING
ZIOTC_MSG_TYPE_DATA               = pyziotc.MSG_OUT_DATA
ZIOTC_MSG_TYPE_CTRL               = pyziotc.MSG_OUT_CTRL
ZIOTC_MSG_TYPE_GPO                = pyziotc.MSG_OUT_GPO
ZIOTC_MSG_TYPE_GPI                = pyziotc.MSG_IN_GPI

class ZIOTC:

    def __init__(self):
        
        self.z = pyziotc.Ziotc()
        self.epoll_fd = self.z.incomingMsgEventFD      
        self.loop = asyncio.get_event_loop()
        self.loop.add_reader(self.epoll_fd, self.processNextMsg)
        self.loop.add_signal_handler(signal.SIGINT, self.on_trap, self.loop)
        self.new_msg_fcn = None

    def on_trap(self, loop):
        print("loop is stopping...")
        for t in asyncio.all_tasks():
            print(t)
            print(t.cancelled())
            t.cancel()
            print(t.cancelled())
        loop.call_soon_threadsafe(loop.stop)
        print("loop stopped")
        del(self.z)

    def obj_pass_thru_fcn(self, msg_in):
        incoming_message = bytearray(msg_in, "utf-8")
        return self.pass_thru_fcn(incoming_message)

    def reg_pass_through_callback(self, pass_thru_fcn):
        self.pass_thru_fcn = pass_thru_fcn
        return self.z.reg_pass_through_callback(self.obj_pass_thru_fcn)

    def processNextMsg(self):
        count = 0
        n = struct.unpack("Q", os.read(self.epoll_fd, 8))[0]
        for i in range(n):
            count = count+1

            if count%100 == 0:
                print(count)
                
            response = self.z.recv_next_msg()
            if response != None:
                message_type = response[0]
                incoming_message = bytearray(response[1],"utf-8")
                #message_source = response[2]
            self.new_msg_fcn(message_type, incoming_message)

    def reg_new_msg_callback(self, new_msg_fcn):
        self.new_msg_fcn = new_msg_fcn

    def send_next_msg(self, msg_type, msg):
        return self.z.send_next_msg(msg_type,bytearray(msg))

    def enableGPIEvents(self):
        return self.z.enableGPIEvents()

    def disableGPIEvents(self):
        return self.z.disableGPIEvents()
