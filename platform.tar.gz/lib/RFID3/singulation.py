import enum

from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class SESSION(enum.Enum):
    SESSION_S0 = 0
    SESSION_S1 = 1
    SESSION_S2 = 2
    SESSION_S3 = 3


class INVENTORY_STATE(enum.Enum):
    INVENTORY_STATE_A = 0
    INVENTORY_STATE_B = 1
    INVENTORY_STATE_AB_FLIP = 2


class SL_FLAG(enum.Enum):
    SL_FLAG_ASSERTED = 0
    SL_FLAG_DEASSERTED = 1
    SL_ALL = 2


class SingulationControlStruct:

    def __init__(self, config):
        self.session = SESSION(config.session)
        self.tagPopulation = config.tagPopulation
        self.tagTransitTimeMilliseconds = config.tagTransitTimeMilliseconds
        self.stateAwareSingulationAction = STATE_AWARE_SINGULATION_ACTION(
            config.stateAwareSingulationAction)

    def __str__(self):
        return "Singulation settings:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


class STATE_AWARE_SINGULATION_ACTION:

    def __init__(self, config):
        self.perform = config.perform
        self.inventoryState = INVENTORY_STATE(config.inventoryState)
        self.slFlag = SL_FLAG(config.slFlag)

    def __str__(self):
        return ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


# noinspection PyMethodMayBeStatic
class SingulationControl:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Get(self, antenna):
        """
        Get Singulation settings for antenna
        :param antenna: antenna id
        :return: Singulation Struct
        """
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        log.info("Getting singulation settings for antenna {}".format(antenna))
        singulation_control = ffi.new("LPSINGULATION_CONTROL")

        status = lib.RFID_GetSingulationControl(
            self.reader_handle, antenna, singulation_control)

        if VerifyStatus(status):
            singulation_setting = SingulationControlStruct(singulation_control)
            log.info("singulation for antenna {}: {}".format(
                antenna, singulation_setting))
            return singulation_setting
        else:
            log.error("get singulation for antenna {} failed.".format(antenna))
            return None

    def Set(self, config, antenna=0):
        """
        Set Singulation settings for antenna
        :param config: SingulationStruct object
        :param antenna: antenna
        :return: True if success else False
        """
        assert isinstance(config, SingulationControlStruct), log.error(
            "expected config to be SingulationConfig instance")
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        singulation_control = ffi.new("LPSINGULATION_CONTROL")
        if isinstance(config.session, int):
            session = config.session
        else:
            session = config.session.value
        singulation_control.session = session
        singulation_control.tagPopulation = config.tagPopulation
        singulation_control.tagTransitTimeMilliseconds = config.tagTransitTimeMilliseconds
        singulation_control.stateAwareSingulationAction.perform = config.stateAwareSingulationAction.perform
        if isinstance(config.stateAwareSingulationAction.inventoryState, int):
            inventoryState = config.stateAwareSingulationAction.inventoryState
        else:
            inventoryState = config.stateAwareSingulationAction.inventoryState.value
        singulation_control.stateAwareSingulationAction.inventoryState = inventoryState
        if isinstance(config.stateAwareSingulationAction.slFlag, int):
            slFlag = config.stateAwareSingulationAction.slFlag
        else:
            slFlag = config.stateAwareSingulationAction.slFlag.value
        singulation_control.stateAwareSingulationAction.slFlag = slFlag

        log.info("setting antenna {} config to {}".format(antenna, config))
        status = lib.RFID_SetSingulationControl(
            self.reader_handle, antenna, singulation_control)
        if not VerifyStatus(status):
            log.error("Set singulation for antenna {} failed.".format(antenna))
            return False
        else:
            log.info("Set singulation for antenna {} successful.".format(antenna))
            return True
