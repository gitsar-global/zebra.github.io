import enum

from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class ANTENNA_STOP_TRIGGER_TYPE(enum.Enum):
    ANTENNA_STOP_TRIGGER_TYPE_N_ATTEMPTS = 1
    ANTENNA_STOP_TRIGGER_TYPE_DURATION_MILLISECS = 2
    ANTENNA_STOP_TRIGGER_TYPE_DURATION_SECS = 3


class ANTENNA_STOP_TRIGGER:

    def __init__(self, config):
        self.stopTriggerType = ANTENNA_STOP_TRIGGER_TYPE(
            config.stopTriggerType)
        self.stopTriggerValue = config.stopTriggerValue

    def __str__(self):
        return ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


class AntennaRFConfigStruct:

    def __init__(self, config):
        self.transmitPowerIndex = config.transmitPowerIndex
        self.receiveSensitivityIndex = config.receiveSensitivityIndex
        self.transmitFrequencyIndex = config.transmitFrequencyIndex
        self.rfModeTableIndex = config.rfModeTableIndex
        self.tari = config.tari
        self.transmitPort = config.transmitPort
        self.receivePort = config.receivePort
        self.antennaStopTrigger = ANTENNA_STOP_TRIGGER(
            config.antennaStopTrigger)

    def __str__(self):
        return "Antenna RF Config:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


# noinspection PyMethodMayBeStatic
class AntennaRFConfig:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Get(self, antenna):
        """
        GET Antenna RF config structure
        :param antenna: antenna
        :return: AntennaRFConfigStruct object
        """
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        config = ffi.new("LPANTENNA_RF_CONFIG")
        log.info("getting antenna {} config.".format(antenna))
        status = lib.RFID_GetAntennaRfConfig(
            self.reader_handle, antenna, config)

        if VerifyStatus(status):
            config = AntennaRFConfigStruct(config)
            log.info("antenna {} rf config: {}".format(antenna, config))
            return config
        else:
            log.error(
                "Get antenna config api failed for antenna {}.".format(antenna))
            return None

    def Set(self, config, antenna=0):
        """
        SET Antenna RF config structure
        :param config: AntennaRFConfigStruct object
        :param antenna: antenna
        :return: True if success else False
        """
        assert isinstance(config, AntennaRFConfigStruct), log.error(
            "expected config to be AntennaRfConfig instance")
        assert isinstance(antenna, int), log.error(
            "expected antenna id to be int")

        ant_config = ffi.new("LPANTENNA_RF_CONFIG")
        ant_config.transmitPowerIndex = config.transmitPowerIndex
        ant_config.receiveSensitivityIndex = config.receiveSensitivityIndex
        ant_config.transmitFrequencyIndex = config.transmitFrequencyIndex
        ant_config.rfModeTableIndex = config.rfModeTableIndex
        ant_config.tari = config.tari
        ant_config.transmitPort = config.transmitPort
        ant_config.receivePort = config.receivePort
        if isinstance(config.antennaStopTrigger.stopTriggerType, int):
            stopTriggerType = config.antennaStopTrigger.stopTriggerType
        else:
            stopTriggerType = config.antennaStopTrigger.stopTriggerType.value
        ant_config.antennaStopTrigger.stopTriggerType = stopTriggerType
        ant_config.antennaStopTrigger.stopTriggerValue = config.antennaStopTrigger.stopTriggerValue

        log.info("setting antenna {} config to {}".format(antenna, config))
        status = lib.RFID_SetAntennaRfConfig(
            self.reader_handle, antenna, ant_config)
        if not VerifyStatus(status):
            log.error(
                "Set antenna config api failed for antenna {}.".format(antenna))
            return False
        else:
            log.info(
                "Set antenna config api success for antenna {}.".format(antenna))
            return True
