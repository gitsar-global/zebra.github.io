import time

from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus
from RFID3.inventory import Inventory
from RFID3.prefilters import PreFilters
from RFID3.tagdata import TagData


class Action:

    def __init__(self, reader_handle):

        self.reader_handle = reader_handle

        # max pre allocated Tag memory default 1000
        self.max_tag_count = 1000
        # tag data structure
        self.tag_data = None
        # Tag data
        self.processed_tags = []
        # Tag count returned
        self.tagCountReturned = ffi.new("UINT32*")

        self.Inventory = Inventory(reader_handle)
        self.PreFilters = PreFilters(reader_handle)

    @property
    def max_tag_buffer(self):
        """
        max number of tag buffer based
        """
        return self.max_tag_count

    @max_tag_buffer.setter
    def max_tag_buffer(self, count):
        """
        max number of tag buffer based
        """
        if count:
            self.max_tag_count = count
            if self.tag_data is not None:
                self.DeAllocateTag()
                self.tag_data = None
                self.AllocateTag()

    def AllocateTag(self):
        """
        Allocate Tag memory
        :return: True if success else False
        """
        log.info("Allocating Tag memory")
        self.tag_data = ffi.new("LPTAG_DATA[{0}]".format(self.max_tag_count))

        if self.tag_data != ffi.NULL:
            for i in range(self.max_tag_count):
                self.tag_data[i] = lib.RFID_AllocateTag(self.reader_handle)
                if self.tag_data[i] == ffi.NULL:
                    log.error("Tag memory: {0} allocation failed.".format(i))
                    self.max_tag_count = i + 1
                    return False

        return True

    def DeAllocateTag(self):
        """
        Deallocate Tag memory
        :return: True if success else False
        """
        log.info("Deallocate Tag memory")
        if self.tag_data != ffi.NULL:
            for i in range(self.max_tag_count):
                dealloc_status = lib.RFID_DeallocateTag(
                    self.reader_handle, self.tag_data[i])
                if not VerifyStatus(dealloc_status):
                    log.error("Deallocate Tag memory {0} failed.".format(i))
        return True

    def GetReadTags(self, count=None, timeout=None, islog=False):
        """
        return tags requested
        :param islog: logging
        :param count: number of tags to be return
        :param timeout: time to return tags
        :return: TagData array
        """
        self.processed_tags = []

        if count and (not isinstance(count, int)):
            return -1

        if (count and count < 0) or (timeout and timeout < 0):
            return -1

        log.debug("Reading tags")
        n = 0
        curr_time = time.time()

        while True:
            # Adjust tags tobe read
            if count == 0 or count is None:
                tagCountRequested = ffi.cast("UINT32", self.max_tag_count)
            elif (count - n) > 0:
                if (count - n) >= self.max_tag_count:
                    tagCountRequested = ffi.cast("UINT32", self.max_tag_count)
                else:
                    tagCountRequested = ffi.cast("UINT32", count - n)
            else:
                break

            status = lib.rfid_GetReadTags(
                self.reader_handle, tagCountRequested, self.tag_data, self.tagCountReturned)
            if VerifyStatus(status, log_=islog):
                if self.tagCountReturned[0] == 0:
                    break

                # print("tagCountReturned: {0}".format(tagCountReturned[0]))
                for i in range(self.tagCountReturned[0]):
                    self.processed_tags.append(TagData(self.tag_data[i]))
                    n += 1

                lib.rfid_DeallocateTags(
                    self.reader_handle, self.tag_data, self.tagCountReturned[0])
            else:
                log.error(
                    "rfid_GetReadTags failed with status: {0}".format(status))
                break

            # break if timeout and count is not configured
            if (timeout is None) and (count == 0 or count is None):
                break

            if count and n >= count:
                break
            if timeout and time.time() - curr_time > timeout:
                break

            # time.sleep(0.005) # Sleep for 5ms to reduce cpu usage

        return 0

    def purgeTags(self):
        """
        Delete all the tags stored in c api layer
        """
        status = lib.RFID_PurgeTags(self.reader_handle, ffi.NULL)
        if not VerifyStatus(status):
            log.error("Failed to purge Tags.")
            return False
        return True
