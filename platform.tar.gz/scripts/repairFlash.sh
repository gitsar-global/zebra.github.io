#!/bin/bash

#trap "kill 0" EXIT

#echo "killing LLRP server"
#sudo pkill llrpserver.elf
echo "starting serTCPBridge in the background"

if (uname -r | grep 4.9)

then

		sudo /platform/bin/serTCPBridge.elf /dev/ttyS1 &
		sleep 1
		echo -ne '\xaa\xab\x08\xd0\x00\x00\x9b\x68' | nc localhost 9180
		echo -ne '\x0d\x0a' | nc localhost 9180
		echo -ne '\x0d\x0a' | nc localhost 9180
		echo -ne 'ver\x0d\x0a' | nc localhost 9180
		
		echo -ne 'iowr -d 1 4 1\x0d\x0a' | nc localhost 9180
		usleep 10000
		echo -ne 'iowr 1 4 1\x0d\x0a' | nc localhost 9180
		usleep 10000
		echo -ne 'spi 5 06\x0d\x0a' | nc localhost 9180
		usleep 10000
		echo -ne 'spi 5 01 0\x0d\x0a' | nc localhost 9180
		usleep 50000
		echo -ne 'spi 5 06\x0d\x0a' | nc localhost 9180
		usleep 10000
		echo -ne 'spi 5 31 0\x0d\x0a' | nc localhost 9180
		usleep 50000
		echo -ne 'spi 5 06\x0d\x0a' | nc localhost 9180
		usleep 10000
		echo -ne 'spi 5 11 0\x0d\x0a' | nc localhost 9180
		usleep 50000
		echo -ne 'iowr -d 1 4 0\x0d\x0a' | nc localhost 9180

else

		sudo /platform/bin/serTCPBridge.elf /dev/ttyO1 &
		sleep 1
		echo -ne '\xaa\xab\x08\xd0\x00\x00\x9b\x68' | nc -i1 localhost 9180
		echo -ne '\x0d\x0a' | nc -i1 localhost 9180
		echo -ne '\x0d\x0a' | nc -i1 localhost 9180
		echo -ne 'ver\x0d\x0a' | nc -i1 localhost 9180
		
		echo -ne 'iowr -d 1 4 1\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.01
		echo -ne 'iowr 1 4 1\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.01
		echo -ne 'spi 5 06\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.01
		echo -ne 'spi 5 01 0\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.05
		echo -ne 'spi 5 06\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.01
		echo -ne 'spi 5 31 0\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.05
		echo -ne 'spi 5 06\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.01
		echo -ne 'spi 5 11 0\x0d\x0a' | nc -i1 localhost 9180
		sleep 0.05
		echo -ne 'iowr -d 1 4 0\x0d\x0a' | nc -i1 localhost 9180
		
fi  

sleep 1
sudo pkill serTCPBridge
sleep 1
#sudo reboot

