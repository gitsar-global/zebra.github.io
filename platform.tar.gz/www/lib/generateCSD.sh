archiveName="MotCSD_`date "+%Y%m%d%H%M%S"`.tar.gz2"
curDir=`pwd`
logsDir=\/readerconfig\/logs
syslogDir=\/var\/log

mkdir $logsDir

cd $syslogDir
for f in `ls core-*`; do
  files+=($f)
done

cd $syslogDir 
for f in `ls messages*`
do
  files+=($f)
done

top -n 1 -b > top-output.txt  

tar czf $archiveName "top-output.txt" "${files[@]}" 

rm -r top-output.txt

cd $curDir




