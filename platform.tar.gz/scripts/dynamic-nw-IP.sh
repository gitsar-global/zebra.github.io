#!/bin/bash

eth0_suspend() {
               echo $1 
                #stop the avahi-autoipd,
                /usr/sbin/avahi-autoipd -k eth0 &> /dev/null

                # Stop the dhcp client (it will kill both V6 and V4 client)
                #IS_DHCPC_RUNNING=`ps -A | grep udhcpc`
                IS_DHCLIENT_RUNNING=`ps -eaf | grep dhclient | grep eth0`
                if [ "${IS_DHCLIENT_RUNNING}" ]
                then
                        ps -eaf | grep dhclient | grep eth0 | awk '{print $2}' | xargs kill -9
                fi
                # Clear all IP addresses assigned to eth0
                ifconfig eth0 0.0.0.0
                #remove the file where the current Zeroconf IP is saved.
                # This is to make sure in case Ip got change due to some
                # IP clash, so on next time n/w cable plugged-in (or device boot-up)
                # Ip will be taken from MAC id instead of old stored IP 
                rm /var/lib/avahi-autoipd/* &> /dev/null
}

ntp_start()
{
    if [[ $(cat  /readerconfig/AdvReaderConfig.xml | grep SNTPHostName | wc -l) != "0" ]]; then  
        ps -A | grep ntpd | awk '{print $1}' | xargs kill -9
        /usr/sbin/ntpd -g -U 0	
	echo "NTP daemon started ......."
    fi
}

NET_STATUS='2'
export LD_LIBRARY_PATH=/usr/lib:$LD_LIBRARY_PATH

NET_CONF_FL="/tmp/net_conf_chng"
NET_CONF_PN="/tmp/pn_conf"

touch ${NET_CONF_FL} 
echo 0 >  ${NET_CONF_FL} 

touch ${NET_CONF_PN}
echo 0 > ${NET_CONF_PN}

COUNT=1
MAX_COUNT=60

DHCP_IP=`ifconfig eth0 | grep 'inet addr:' | awk -F: '{ print $2 }' | awk '{ print $1 }'`

route add -net 224.0.0.0 netmask 240.0.0.0 eth0
resolvconf --enable-updates

while true
do
  	NEW_NET_STATUS=`cat /sys/class/net/eth0/carrier`
        NET_CONF_CHNG=`cat ${NET_CONF_FL}`
	NET_CONF_PN_CHNG=`cat ${NET_CONF_PN}`
	if [ $COUNT == $MAX_COUNT ]
	then
		COUNT='1'
		NEW_DHCP_IP=`ifconfig eth0 | grep 'inet addr:' | awk -F: '{ print $2 }' | awk '{ print $1 }'`
		
		# check if new IP is differ than old dhcp IP, then restart the services (RDMPAgent etc.)
		if [ "${NEW_DHCP_IP}" != "" ] && [  "${DHCP_IP}" != "${NEW_DHCP_IP}" ]
		then
			IS_RDMPAGENT_RUNNING=`ps -A | grep RDMPAgent`

			if [ "${IS_RDMPAGENT_RUNNING}" ]
			then
				ps -A | grep RDMPAgent | awk '{print $1}' | xargs kill -9
			fi

			# delete the route entry
			route del -net 224.0.0.0 netmask 240.0.0.0 eth0 &> /dev/null
			route add -net 224.0.0.0 netmask 240.0.0.0 eth0
			sleep 1
			# now start the RDMP Agent
			if cat /readerconfig/AdvReaderConfig.xml  | grep "RDMPAgentEnabled='0'" > /dev/null
                        then
                            echo "RDMPAgent Config Disabled!"
                        else
                            echo "RDMPAgent Config Enabled! Starting Daemon!"
                            /platform/bin/RDMPAgent &
                        fi

                        ntp_start
                        
			# copy the new IP
			DHCP_IP=${NEW_DHCP_IP}
		fi
	fi

	if [ "${NET_CONF_CHNG}" == "1" ] && [ "${NET_CONF_PN_CHNG}" == "1" ]
	then
		echo 0 >  ${NET_CONF_FL}
		echo 0 > ${NET_CONF_PN}
		IS_RDMPAGENT_RUNNING=`ps -A | grep RDMPAgent`

		if [ "${IS_RDMPAGENT_RUNNING}" ]
		then
			ps -A | grep RDMPAgent | awk '{print $1}' | xargs kill -9
		fi
		#delete the route entry, 
		route del -net 224.0.0.0 netmask 240.0.0.0 eth0 &> /dev/null
		# Add the route entry again for RDMP
		route add -net 224.0.0.0 netmask 240.0.0.0 eth0
		# now start the RDMP agent
		sleep 1

 	        if cat /readerconfig/AdvReaderConfig.xml  | grep "RDMPAgentEnabled='0'" > /dev/null
                then
                    echo "RDMPAgent Config Disabled!"
                else
                    echo "RDMPAgent Config Enabled.Starting RDMPAgent!"
                    /platform/bin/RDMPAgent &
                fi
	        continue
	fi


	COUNT=`expr $COUNT + 1`
	if [ "${NET_CONF_CHNG}" == "1" ]
        then
            NET_STATUS='2'
            echo 0 >  ${NET_CONF_FL}     
            eth0_suspend "network configuration change"
        fi 

	#Is there any change in the n/w status since last call ???
	if [ "${NEW_NET_STATUS}" == "${NET_STATUS}" ]
  	then
   		sleep 1
		continue
  	fi
	
	#IS_DHCPC_RUNNING=`ps -A | grep udhcpc`	
		
	#Yes, there is a change, save the new n/w status
	NET_STATUS=${NEW_NET_STATUS}
	#Check the status new n/w status, plugged or unplugged ??
	if [ "${NET_STATUS}" == 1 ]
	then
		echo "cable plugged in"
		IS_DYNAMIC_IP=`cat /readerconfig/networkscript.sh | grep "#ifconfig eth0"`

		if [ "${IS_DYNAMIC_IP}" ]
		then
			# Stop the dhcp client, if running
			IS_DHCLIENTV4_RUNNING=`ps -eaf | grep dhclient | grep "dhclient -4" | grep eth0`
			if [ "${IS_DHCLIENTV4_RUNNING}" ]
			then
				ps -eaf | grep dhclient | grep "dhclient -4" | grep eth0 | awk '{print $2}' | xargs kill -9
			fi
			# ps -A | grep udhcpc | awk '{print $1}' | xargs kill -9
			#ifconfig eth0 down && ifconfig eth0 up
			
			#start the dhcp cleint with 6 trials and see if gets the IP
			#/sbin/udhcpc --interface=eth0 --tryagain=30 --timeout=5 --retries=10 &
			/sbin/dhclient -4 -cf /etc/dhcp/dhclient.conf -sf /sbin/dhclient-script -lf /readerconfig/dhclient_ethv4.lease eth0 -q &
			
			#delete the route entry, 
			route del -net 224.0.0.0 netmask 240.0.0.0 eth0 &> /dev/null			
			# Add the route entry again for RDMP
			route add -net 224.0.0.0 netmask 240.0.0.0 eth0
		else			
			#delete the route entry, 
			route del -net 224.0.0.0 netmask 240.0.0.0 eth0 &> /dev/null			
			# Add the route entry again for RDMP
			route add -net 224.0.0.0 netmask 240.0.0.0 eth0
			RUN_RDR_CONF_NW_SCRIPT=1
		fi
		
		# check if IPV6 is set for dynamic and no global IP available
		IPV6_IS_STATIC=`cat /readerconfig/networkscript.sh | grep '#/sbin/dhclient'`		
		if [ ! "${IPV6_IS_STATIC}" ] 
		then
			# first kill the running one ....
			IS_DHCLIENTV6_RUNNING=`ps -eaf | grep dhclient | grep "dhclient -6" | grep eth0`
			if [ "${IS_DHCLIENTV6_RUNNING}" ]
			then
				ps -eaf | grep dhclient | grep "dhclient -6" | grep eth0 | awk '{print $2}' | xargs kill -9
			fi	
			# start the dhclient again, to get the new dhcp IP
			/sbin/dhclient -6 -nw -cf /etc/dhcp/dhclient.conf.6 -sf /sbin/dhclient-script -lf /readerconfig/dhclient_ethv6.lease eth0 -q
		else
			RUN_RDR_CONF_NW_SCRIPT=1
		fi
		
		if [ "$RUN_RDR_CONF_NW_SCRIPT" == "1" ];then
			#configure static IP for both IPv4 and IPv6
			/readerconfig/networkscript.sh
			RUN_RDR_CONF_NW_SCRIPT=0;
		fi

		#start the zeroconf daemon
#	cat /readerconfig/AdvReaderConfig.xml  | grep "AvahiEnabled='1'" > /dev/null && /platform/bin/startavahi.elf 			
               if cat /readerconfig/AdvReaderConfig.xml  | grep "AvahiEnabled='0'" > /dev/null
               then
                  echo "Avahi Config Disabled!"
               else
                  echo "Avahi Config Enabled Starting daemon!"
		  /platform/bin/startavahi.elf
               fi

		# Stop the RDMPAgent
		IS_RDMPAGENT_RUNNING=`ps -A | grep RDMPAgent`
		
		if [ "${IS_RDMPAGENT_RUNNING}" ]
		then
			#ps -A | grep RDMPAgent | awk '{print $1}' | xargs kill -9
			RDMP_ID=`ps -A | grep RDMP`
			echo $RDMP_ID
			pkill -f RDMP
		fi
		
		# Wait for a moment to make sure we get at least ZeroConf IP ....
		# TODO: if RDMPAgent can start with at least one IP available (USB0) then this wait is not required
		sleep 5
		# now start the RDMP agent
	       if cat /readerconfig/AdvReaderConfig.xml  | grep "RDMPAgentEnabled='0'" > /dev/null
               then
                  echo "RDMPAgent Config Disabled!"
               else
                  echo "RDMPAgent Config Enabled! Starting Daemon!"
                  /platform/bin/RDMPAgent &
               fi

                ntp_start
		
	else
	     eth0_suspend "cable unplugged"
	fi
        if [ "${NET_CONF_CHNG}"  == "1" ]; then  
             NET_CONF_CHNG=0
        fi 
  	sleep 1
done

