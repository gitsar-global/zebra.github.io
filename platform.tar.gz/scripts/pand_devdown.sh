#!/bin/bash
/etc/bluetooth/pand_action.sh down
