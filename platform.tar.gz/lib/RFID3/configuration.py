# noinspection PyMethodMayBeStatic
from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus
from RFID3.antennaconfig import AntennaConfig
from RFID3.antennarfconfig import AntennaRFConfig
from RFID3.gpioconfig import GPOConfig, GPIConfig
from RFID3.rfmodeconfig import RFModeConfig
from RFID3.singulation import SingulationControl


class Config:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle
        self.SingulationControl = SingulationControl(reader_handle)
        self.GPOConfig = GPOConfig(reader_handle)
        self.GPIConfig = GPIConfig(reader_handle)
        self.AntennaConfig = AntennaConfig(reader_handle)
        self.RFModeConfig = RFModeConfig(reader_handle)
        self.AntennaRFConfig = AntennaRFConfig(reader_handle)

    @property
    def DiscardTagsOnInventoryStop(self):
        """
        returns discard tags on stop inventory flag
        :return: None
        """
        log.info("Getting Tag storage settings.")
        tag_settings = ffi.new("TAG_STORAGE_SETTINGS *")
        status = lib.RFID_GetTagStorageSettings(
            self.reader_handle, tag_settings)
        VerifyStatus(status)
        log.info("discard tags on stop inventory: {}".format(
            bool(tag_settings.discardTagsOnInventoryStop)))
        return bool(tag_settings.discardTagsOnInventoryStop)

    @DiscardTagsOnInventoryStop.setter
    def DiscardTagsOnInventoryStop(self, flag):
        """
        sets discard tags on stop inventory flag
        :param flag: True to ENABLE False to DISABLE
        :return: None
        """
        log.info("Getting Tag storage settings.")
        tag_settings = ffi.new("TAG_STORAGE_SETTINGS *")
        log.info("setting discard tags on stop inventory to {}".format(flag))
        # get tag settings
        status = lib.RFID_GetTagStorageSettings(
            self.reader_handle, tag_settings)
        VerifyStatus(status)
        log.info("Setting Tag storage settings.")
        # changing flag
        tag_settings.discardTagsOnInventoryStop = 1 if flag else 0
        # set tag settings
        status = lib.RFID_SetTagStorageSettings(
            self.reader_handle, tag_settings)
        VerifyStatus(status)

    def GetPhysicalAntennaProperties(self, antennaID):
        """
        Get the antenna property
        :return: (Status, AntennaGain)
        """
        pStatus = ffi.new("BOOLEAN *")
        pAntennaGain = ffi.new("UINT32*")

        status = lib.RFID_GetPhysicalAntennaProperties(
            readerHandle, antennaID, pStatus, pAntennaGain)

        if VerifyStatus(status):
            return bool(ffi.cast('char', pStatus[0])), pAntennaGain
        else:
            return None
