import enum

from rfidapi32py import ffi


class START_TRIGGER_TYPE(enum.Enum):
    START_TRIGGER_TYPE_IMMEDIATE = 0
    START_TRIGGER_TYPE_PERIODIC = 1
    START_TRIGGER_TYPE_GPI = 2
    START_TRIGGER_TYPE_HANDHELD = 3


class STOP_TRIGGER_TYPE(enum.Enum):
    STOP_TRIGGER_TYPE_IMMEDIATE = 0
    STOP_TRIGGER_TYPE_DURATION = 1
    STOP_TRIGGER_TYPE_GPI_WITH_TIMEOUT = 2
    STOP_TRIGGER_TYPE_TAG_OBSERVATION_WITH_TIMEOUT = 3
    STOP_TRIGGER_TYPE_N_ATTEMPTS_WITH_TIMEOUT = 4
    STOP_TRIGGER_TYPE_HANDHELD_WITH_TIMEOUT = 5


class TriggerInfo:

    def __init__(self):
        self.struct = ffi.new("TRIGGER_INFO *")
        self.startTrigger = StartTrigger(self)
        self.stopTrigger = StopTrigger(self)
        self.reportTriggers = ReportTriggers(self)

    def GetTriggerInfo(self):
        """
        return trigger
        :return: TRIGGER_INFO struct
        """
        return self.struct


class StartTrigger:

    def __init__(self, trigger):
        self.trigger = trigger

    def Immediate(self):
        """
        Set start trigger type as Immediate
        :return: None
        """
        self.trigger.struct.startTrigger.type = START_TRIGGER_TYPE.START_TRIGGER_TYPE_IMMEDIATE.value

    def GPI(self, portNumber, gpiEvent, timeoutMilliseconds):
        """
        Set start trigger type as GPI
        :param portNumber: GPI port number
        :param gpiEvent: gpi event True of False
        :param timeoutMilliseconds: timeout
        :return: None
        """
        self.trigger.struct.startTrigger.type = START_TRIGGER_TYPE.START_TRIGGER_TYPE_GPI.value
        self.trigger.struct.startTrigger.value.gpi.portNumber = portNumber
        self.trigger.struct.startTrigger.value.gpi.gpiEvent = gpiEvent
        self.trigger.struct.startTrigger.value.gpi.timeoutMilliseconds = timeoutMilliseconds

    def Periodic(self, periodMilliseconds, startTime):
        """
        Set start trigger type as periodic
        :param periodMilliseconds: timeout
        :param startTime: SYSTEMTIME * struct object
        :return: None
        """
        self.trigger.struct.startTrigger.type = START_TRIGGER_TYPE.START_TRIGGER_TYPE_PERIODIC.value
        self.trigger.struct.startTrigger.value.periodic.periodMilliseconds = periodMilliseconds
        self.trigger.struct.startTrigger.value.periodic.startTime = startTime

    def Handheld(self):
        """
        Set start trigger type as handheld
        :return: None
        """
        self.trigger.struct.startTrigger.type = START_TRIGGER_TYPE.START_TRIGGER_TYPE_HANDHELD.value
        # TODO complete handheld trigger type


class StopTrigger:

    def __init__(self, trigger):
        self.trigger = trigger

    def Immediate(self):
        """
        Set stop trigger type as immediate
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_IMMEDIATE.value

    def Duration(self, duration):
        """
        Set stop trigger type as duration
        :param duration: timeout
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_DURATION.value
        self.trigger.struct.stopTrigger.value.duration = duration

    def GPI(self, portNumber, gpiEvent, timeoutMilliseconds):
        """
        Set stop trigger type as GPI
        :param portNumber: GPI port number
        :param gpiEvent: gpi event True of False
        :param timeoutMilliseconds: timeout
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_GPI_WITH_TIMEOUT.value
        self.trigger.struct.startTrigger.value.gpi.portNumber = portNumber
        self.trigger.struct.startTrigger.value.gpi.gpiEvent = gpiEvent
        self.trigger.struct.startTrigger.value.gpi.timeoutMilliseconds = timeoutMilliseconds

    def TagObservationWithTimeout(self, n, timeoutMilliseconds):
        """
        Set stop trigger to tag observation with timeout
        :param n: number of tag observations
        :param timeoutMilliseconds: inventory time
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_TAG_OBSERVATION_WITH_TIMEOUT.value
        self.trigger.struct.stopTrigger.value.tagObservation.timeoutMilliseconds = timeoutMilliseconds
        self.trigger.struct.stopTrigger.value.tagObservation.n = n

    def NAttemptWithTimeout(self, n, timeoutMilliseconds):
        """
        Set stop trigger to n attempt with timeout
        :param n: number of inventory rounds
        :param timeoutMilliseconds: inventory time
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_N_ATTEMPTS_WITH_TIMEOUT.value
        self.trigger.struct.stopTrigger.value.numAttempts.timeoutMilliseconds = timeoutMilliseconds
        self.trigger.struct.stopTrigger.value.numAttempts.n = n

    def Handheld(self):
        """
        Set stop trigger to handheld mode
        :return: None
        """
        self.trigger.struct.stopTrigger.type = STOP_TRIGGER_TYPE.STOP_TRIGGER_TYPE_HANDHELD_WITH_TIMEOUT.value
        # TODO complete handheld trigger type


class ReportTriggers:

    def __init__(self, trigger):
        self.trigger = trigger

    def periodicReportDuration(self, duration, tagReportTrigger=None):
        """
        specifies configuration different type of reporting trigger mechanisms.
        """
        if (tagReportTrigger is None or tagReportTrigger <= 0 or (not isinstance(tagReportTrigger, int))):
            self.trigger.struct.tagReportTrigger = 0
        else:
            self.trigger.struct.tagReportTrigger = tagReportTrigger

        self.trigger.struct.lpTagEventReportInfo = ffi.NULL
        self.trigger.struct.lpReportTriggers = ffi.new("REPORT_TRIGGERS *")

        if (duration < 0 or not isinstance(duration, int)):
            self.trigger.struct.lpReportTriggers.periodicReportDuration = ffi.cast(
                "UINT32", 0)
        else:
            self.trigger.struct.lpReportTriggers.periodicReportDuration = ffi.cast(
                "UINT32", duration)
