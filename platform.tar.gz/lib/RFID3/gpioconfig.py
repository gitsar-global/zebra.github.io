import enum

from rfidapi32py import ffi, lib

from RFID3.support import log, VerifyStatus


class GPI_STATE(enum.Enum):
    LOW = 0
    HIGH = 1
    UNKOWN = 2


class GPI_STATUS(enum.Enum):
    ENABLE = 1
    DISABLE = 0


class GPO_STATE(enum.Enum):
    ENABLE = 1
    DISABLE = 0


class GPIStruct:

    def __init__(self, state, status):
        self.state = state
        self.status = status

    def __str__(self):
        return "GPI Config:\n" + ''.join(list(map(lambda x: "{}: {}\n".format(x[0], x[1]), self.__dict__.items())))


# noinspection PyMethodMayBeStatic
class GPOConfig:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Set(self, pin, state):
        """
        SET GPO pin state
        :param pin: GPO pin number
        :param state: pin state
        :return: True if api success else False
        """
        assert isinstance(pin, int), log.error("expected pin to be int")
        assert isinstance(state, bool), log.error("expected state to be bool")

        log.info("setting GPO {} to {}".format(pin, state))
        state = 1 if state else 0
        status = lib.RFID_SetGPOState(self.reader_handle, pin, state)
        return VerifyStatus(status)

    def Get(self, pin):
        """
        GET GPO pin state
        :param pin: GPO pin number
        :return:
        """
        assert isinstance(pin, int), log.error("expected pin to be int")

        gpo_state = ffi.new("unsigned char *")

        log.info("getting GPO {} state".format(pin))
        status = lib.RFID_GetGPOState(self.reader_handle, pin, gpo_state)

        if VerifyStatus(status):
            log.info("GPO {} state {}".format(pin, GPO_STATE(gpo_state[0])))
            return GPO_STATE(gpo_state[0])
        else:
            log.error("Getting GPO {} failed".format(pin))
            return None


# noinspection PyMethodMayBeStatic
class GPIConfig:

    def __init__(self, reader_handle):
        self.reader_handle = reader_handle

    def Get(self, pin):
        """
        GET GPI pin state
        :param pin: pin number
        :return: GPIStruct object or None
        """
        assert isinstance(pin, int), log.error("expected pin to be int")

        pin_status = ffi.new("unsigned char *")
        pin_state = ffi.new("GPI_PORT_STATE *")

        log.info("getting gpi {} state".format(pin))
        status = lib.RFID_GetGPIState(
            self.reader_handle, pin, pin_status, pin_state)

        if VerifyStatus(status):
            log.info("GPI {} status: {}, state: {}".format(
                pin, GPI_STATUS(pin_status[0]), GPI_STATE(pin_state[0])))
            return GPIStruct(state=GPI_STATE(pin_state[0]), status=GPI_STATUS(pin_status[0]))
        else:
            log.error("Failed to get GPI state")
            return None
